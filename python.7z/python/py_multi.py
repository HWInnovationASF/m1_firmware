from multiprocessing import Process, Queue, Lock,Value,Manager, Pool
from ctypes import c_char_p
from filelock import FileLock

import sys
import traceback

# import py_function_inc1
from py_function_inc1 import main_m1
from py_function_custom1 import m1_custom1
import ast
import json
import time
from datetime import datetime
import subprocess
import serial
import os

from base64 import b64encode, b64decode 
from Crypto.Cipher import AES #pip install pycryptodome
from Crypto.Util.Padding import pad,unpad

import paho.mqtt.client as mqtt
import RPi.GPIO as GPIO


# ////////////////////// Part main function //////////////////////
def worker(lock,k,p,c,meterSN,rgl,lasttime_send_status,m_arr,g_cne,para_arr,global_arr,manager):
    # for show debug read all
    debug_ = True
    data_device_cmd = dict()
    return_status   = dict()
    raw_read_arr    = dict()
    # print(f'data : {p}')
    # print(f'===PRE t_i_m_e==={datetime.fromtimestamp(lasttime_send_status).strftime("%Y-%m-%d %H:%M:%S")}')       
    
    with lock:
        try:
            GPIO.setmode(GPIO.BCM)
            GPIO.setup(17, GPIO.IN)  # Set +11,-09 ,DI0
            GPIO.setup(27, GPIO.IN)  # Set +15,-13 ,DI1

            GPIO.setup(23, GPIO.OUT) 
            GPIO.setup(24, GPIO.OUT)
            
            if isinstance(p,dict):
                # print(f"Working on {n} - {p}")
                # print(rgl)
                if 'mode' in p:
                    # d0_arr = dict()
                    
                    if p['mode'].lower() == 'tcp':
                        if 'ipaddress' in p:
                            port_485 = int(p['port']) if 'port' in p else 502
                            deviceID_485 = int(p['deviceID']) if 'deviceID' in p else 1
                            instrument = m1_class.tcpconfig(p['ipaddress'],deviceID_485,port_485,1)
                            # start_t = int(time.time())
                            start_reg = 0
                            for cmd_id in c:
                                for cmd_act in c[cmd_id]:
                                    return_status[cmd_act] = False
                                    
                                    cml_arr = c[cmd_id][cmd_act]
                                    if meterSN in cml_arr:
                                        valid_values = [v for v in cml_arr[meterSN] if v is not None]
                                        min_reg = min(valid_values)
                                        max_reg = max(valid_values)
                                        if cmd_act == "read_holding_tcp":
                                            # print(f'===MIN:  {cml_arr}')
                                            # Filter out None
                                            
                                            if min_reg == max_reg:
                                                max_reg=max_reg+2
                                            length_485 = int(max_reg - min_reg) if int(max_reg - min_reg) < 125 else 125
                                            
                                    
                                            data_mb_read = m1_class.readmodbustcp(instrument,int(min_reg),int(length_485),3)
                                            # print(f"Working on [{meterSN}] - {min_reg},{max_reg} = {len(data_mb_read)} | [{data_mb_read}]")
                                            data_read = {}
                                            if "data" in data_mb_read:
                                                data_read = json.loads(data_mb_read['data']) if m1_class.is_json(data_mb_read['data']) else ast.literal_eval(data_mb_read['data'])
                                                raw_read_arr[cmd_id] = data_read

                                        msg_req2 = {}
                                        msg_req2[cmd_id] = {"fn": cmd_act, "sn": meterSN, "params": cml_arr[meterSN]}
                                        msg_req = {"method": "req", "data": msg_req2}
                                        m1_class.log_action(json.dumps(msg_req),"log5","a")
                                        m1_class.log_action(json.dumps(msg_req),"log1","a")
                                        # print(msg_req)
                                        start_reg = min_reg if valid_values else 0
                                        data_command = {}
                                        if cmd_id in raw_read_arr:
                                            
                                            data_command = m1_class.convert_data(raw_read_arr[cmd_id],rgl[p['model']],start_reg)
                                            if meterSN == 'IN159012':
                                                # print((rgl[p['model']]))
                                                print(f'=== Debug[{cmd_id}] : {data_command}')
                                                print(f'=== Pre : {raw_read_arr[cmd_id]}')
                                                print(f'=== {m1_class.convert_data(raw_read_arr[cmd_id],rgl[p["model"]],start_reg)}')
                                            if debug_ == True:
                                                print("[{}][{}][modbusTCP] >> {} | {}".format(m1_class.get_current(),m1_class.deviceSN,meterSN,cml_arr[meterSN]))
                                                print("[{}][{}][modbusTCP] << {} | {}".format(m1_class.get_current(),m1_class.deviceSN,meterSN,data_command))
                                            
                                        if data_command != {}:
                                            data_command_2 = dict()
                                            data_command_2[meterSN] = data_command
                                            # data_device_cmd[cmd_id] = data_command_2[meterSN]
                                            if not cmd_id in data_device_cmd:
                                                data_device_cmd[cmd_id] = {}
                                            data_device_cmd[cmd_id] = data_command
                                            if os.path.isfile('alarm_config.json'):
                                                alarm_txt = m1_class.read_file('alarm_config.json')
                                                alarm_arr = json.loads(alarm_txt) if m1_class.is_json(alarm_txt) else {}
                                                
                                                # print("===alarm_txt===",alarm_arr)
                                                if alarm_arr and m1_class.deviceSN in alarm_arr:
                                                    # print("===alarm_txt===",dev_list,alarm_arr[serial_main])
                                                    # print("===data_device_cmd==",dev_list,data_device_cmd)

                                                    if meterSN in alarm_arr[m1_class.deviceSN]:
                                                        
                                                        if 'AlertConfig' in alarm_arr[m1_class.deviceSN][meterSN]:
                                                            alarm_list = alarm_arr[m1_class.deviceSN][meterSN]['AlertConfig']
                                                            # print("===alarm_txt===",alarm_arr[m1_class.deviceSN][meterSN]['AlertConfig'])
                                                            # print("===2==",data_command_2[meterSN])
                                                            for k_alarm in alarm_arr[m1_class.deviceSN][meterSN]['AlertConfig']:
                                                                # print(k_alarm,data_command_2[meterSN])
                                                                if k_alarm in data_command_2[meterSN]:
                                                                    if alarm_list[k_alarm]['Active'] == 1:
                                                                        # print("==Alarm==",alarm_list[k_alarm]['Alarm'])
                                                                        # print("==Warning==",alarm_list[k_alarm]['Warning'])
                                                                        if alarm_list[k_alarm]['Warning'] is None:
                                                                            alarm_list[k_alarm]['Warning']['Max'] = 0
                                                                            alarm_list[k_alarm]['Warning']['Min'] = 0
                                                                        if alarm_list[k_alarm]['Alarm'] is None:
                                                                            alarm_list[k_alarm]['Alarm']['Max'] = 0
                                                                            alarm_list[k_alarm]['Alarm']['Min'] = 0
                                                                        # if alarm_list[k_alarm]['Warning'] is not None:
                                                                        # print("==Alarm==",alarm_list[k_alarm]['Alarm'])
                                                                        
                                                                        # if float(data_command_2[dev_list][k_alarm]) >= float(alarm_list[k_alarm]['Warning']['Max']) or float(data_command_2[dev_list][k_alarm]) <= float(alarm_list[k_alarm]['Warning']['Min']):
                                                                        if data_command_2[meterSN][k_alarm]:
                                                                            # print(f'===={type(data_command_2[dev_list][k_alarm])}')
                                                                            # print(f'===={float(data_command_2[dev_list][k_alarm])}')
                                                                            v_local = float(data_command_2[meterSN][k_alarm])
                                                                        
                                                                            # if alarm_list[k_alarm]['Alarm']['Min'] or alarm_list[k_alarm]['Alarm']['Max'] :
                                                                                # print(f'==Min: {alarm_list[k_alarm]["Alarm"]["Min"]}')
                                                                                # print(f'==Max: {alarm_list[k_alarm]["Alarm"]["Max"]}')
                                                                            print(f'==Max: {alarm_list[k_alarm]}')
                                                                                
                                                                            alarm_min = float(alarm_list[k_alarm]['Alarm']['Min']) if alarm_list[k_alarm]['Alarm']['Min'] != '' else 0.0
                                                                            alarm_max = float(alarm_list[k_alarm]['Alarm']['Max']) if alarm_list[k_alarm]['Alarm']['Max'] != '' else alarm_min
                                                                            warn_min = float(alarm_list[k_alarm]['Warning']['Min']) if alarm_list[k_alarm]['Warning']['Min'] != '' else 0.0
                                                                            warn_max = float(alarm_list[k_alarm]['Warning']['Max']) if alarm_list[k_alarm]['Warning']['Max'] != '' else warn_min
                                                                            
                                                                            # if alarm_max < alarm_min:
                                                                            #     alarm_max = alarm_min
                                                                            print(f'Alarm=={v_local}== min: {alarm_min} , max: {alarm_max}')
                                                                            print(f'Warnn=={v_local}== min: {warn_min} , max: {warn_max}')
                                                                            
                                                                            if v_local >= warn_max or v_local >= alarm_max or v_local <= warn_min or v_local <= alarm_min:
                                                                                print(f'=={meterSN} : {data_command_2}')
                                                                                if not 'alarm_arr' in global_arr:
                                                                                    global_arr['alarm_arr'] = {}
                                                                                tmp = global_arr['alarm_arr']
                                                                                if not m1_class.deviceSN in tmp:
                                                                                    tmp[m1_class.deviceSN] = {}
                                                                                if not meterSN in tmp[m1_class.deviceSN]:
                                                                                    tmp[m1_class.deviceSN][meterSN] = {}
                                                                                if not k_alarm in tmp[m1_class.deviceSN][meterSN]:
                                                                                    tmp[m1_class.deviceSN][meterSN][k_alarm] = int(time.time())
                                                                                print(f'==={int(time.time())}===={tmp[m1_class.deviceSN][meterSN]}====last:[{int(lasttime_send_status.value)}]')
                                                                                if not 'status_alarm' in tmp:
                                                                                    tmp['status_alarm'] = 0
                                                                                if tmp['status_alarm'] == 0 and int(time.time()) >= int(lasttime_send_status.value):
                                                                                    tmp['status_alarm'] = 1
                                                                                    tmp[m1_class.deviceSN][meterSN][k_alarm] = int(time.time())
                                                                                # print(f'==={int(time.time())}===={tmp[m1_class.deviceSN][meterSN]}====last:[{int(lasttime_send_status.value)}]')
                                                                                global_arr['alarm_arr'] = tmp
                                                                                
                                                                                
                                                                            # print(f'===={alarm_list[k_alarm]['Alarm']}')
                                                                                # print(f'==={v_local} == {alarm_min} | {alarm_max}') 
                                                                            # if alarm_min >= v_local >= alarm_max:
                                                                                
                                                                                
                                                                            #     print(f'=={v_local}== min: {alarm_min} , max: {alarm_max}')
                                                                            #     # print(k_alarm,data_command_2[dev_list])
                                                                            #     a1_alarm = dict()
                                                                            #     a1_alarm["mode"] = "alarm"
                                                                            #     a1_alarm["device_SN"] = m1_class.deviceSN
                                                                            #     a1_alarm["data"] = data_command_2
                                                                            #     a1_alarm["ts"] = int(time.time())
                                                                            #     a1_alarm["dt"] = datetime.fromtimestamp(int(time.time())).strftime("%Y-%m-%d %H:%M:%S")
                                                                            #     # print(f"== Alarm == {a1_alarm}")
                                                                            #     m1_class.log_server(json.dumps(a1_alarm),"log5","a")
                                                                                # m1_class.http_send('alarm',  data_command_2, g_cne=g_cne.value)
                                            # # /////////////////////////////////////////////////////////////////////
                                            
                                            data_res = dict()
                                            data_res_2 = dict()
                                            data_res_4 = dict()

                                            data_res_2['cmdid'] = cmd_id
                                            data_res_2['meter_SN'] = meterSN
                                            data_res_2['data']  = data_device_cmd[cmd_id]
                                            
                                            # data_res_4[dev_list] = convert_data(data_read,rgl_arr[deviceModel],start_reg)
                                            data_res_4[meterSN] =  data_command
                                            if cmd_id not in m_arr:
                                                m_arr[cmd_id] = {}
                                            m_arr[cmd_id] = data_res_4 #Global data meter

                                            if data_device_cmd[cmd_id]:
                                                data_res_2['result'] = 1
                                                data_res_2['error'] = ""
                                            else:
                                                data_res_2['result'] = 0
                                                data_res_2['error'] = ""


                                            data_res['method'] = "res"
                                            data_res['data'] = data_res_2
                                            msg_2_log = json.dumps(data_res)
                                            # if hostname == "172.16.21.114":
                                            # print(msg_2_log)
                                            status_res_log5 = m1_class.log_action(msg_2_log,"log5","a")
                                            status_res_log1 = m1_class.log_action(msg_2_log,"log1","a")
                                            return_status[cmd_act] = True
                    elif p['mode'].lower() == 'rtu':
                        if 'deviceID' in p:
                            # print(f"RTU on {p}")
                            dvl_id = int(p['deviceID']) if 'deviceID' in p else 1
                            dvl_baurdrate = int(p['baurdrate']) if 'baurdrate' in p else 9600
                            dvl_parity = p['parity'] if 'parity' in p else 'none'
                            parity_list = {'none':serial.PARITY_NONE,'even':serial.PARITY_EVEN}
                            instrument = m1_class.rtuconfig(dvl_id,dvl_baurdrate,parity_list[dvl_parity],timeouts=1)
                            # start_t = int(time.time())
                            start_reg = 0
                            for cmd_id in c:
                                for cmd_act in c[cmd_id]:
                                    return_status[cmd_act] = False
                                    
                                    cml_arr = c[cmd_id][cmd_act]
                                    if meterSN in cml_arr:
                                        valid_values = [v for v in cml_arr[meterSN] if v is not None]
                                        min_reg = min(valid_values)
                                        max_reg = max(valid_values)
                                        if cmd_act == "read_holding_rtu":
                                            # valid_values = [v for v in cml_arr[meterSN] if v is not None]
                                            # min_reg = min(valid_values)
                                            # max_reg = max(valid_values)
                                            if min_reg == max_reg:
                                                max_reg=max_reg+2
                                            length_485 = int(max_reg - min_reg) if int(max_reg - min_reg) < 125 else 125
                                            
                                    
                                            data_mb_read = m1_class.readmodbusrtu(instrument,int(min_reg),int(length_485),3)
                                            # print(f"Working on [{meterSN}] - {min_reg},{max_reg} = {len(data_mb_read)}")
                                            data_read = {}
                                            if "data" in data_mb_read:
                                                data_read = json.loads(data_mb_read['data']) if m1_class.is_json(data_mb_read['data']) else ast.literal_eval(data_mb_read['data'])
                                                raw_read_arr[cmd_id] = data_read
                                        msg_req2 = {}
                                        msg_req2[cmd_id] = {"fn": cmd_act, "sn": meterSN, "params": cml_arr[meterSN]}
                                        msg_req = {"method": "req", "data": msg_req2}
                                        m1_class.log_action(json.dumps(msg_req),"log5","a")
                                        m1_class.log_action(json.dumps(msg_req),"log1","a")
                                        # print(msg_req)
                                        start_reg = min_reg if valid_values else 0
                                        data_command = {}
                                        if cmd_id in raw_read_arr:
                                            # print((rgl[p['model']]))
                                            data_command = m1_class.convert_data(raw_read_arr[cmd_id],rgl[p['model']],start_reg)
                                            
                                            # if debug_ == True:
                                            print("[{}][{}][modbusRTU] >> {} | {}".format(m1_class.get_current(),m1_class.deviceSN,meterSN,cml_arr[meterSN]))
                                            print("[{}][{}][modbusRTU] << {} | {}".format(m1_class.get_current(),m1_class.deviceSN,meterSN,data_command))
                                            
                                        if data_command != {}:
                                            # data_command_2[meterSN] = data_command
                                            # data_device_cmd[cmd_id] = data_command_2[meterSN]
                                            if not cmd_id in data_device_cmd:
                                                data_device_cmd[cmd_id] = {}
                                            data_device_cmd[cmd_id] = data_command
                                            
                                            data_res = dict()
                                            data_res_2 = dict()
                                            data_res_4 = dict()

                                            data_res_2['cmdid'] = cmd_id
                                            data_res_2['meter_SN'] = meterSN
                                            data_res_2['data']  = data_device_cmd[cmd_id]
                                            
                                            # data_res_4[dev_list] = convert_data(data_read,rgl_arr[deviceModel],start_reg)
                                            data_res_4[meterSN] =  data_command
                                            if cmd_id not in m_arr:
                                                m_arr[cmd_id] = {}
                                            m_arr[cmd_id] = data_res_4 #Global data meter

                                            if data_device_cmd[cmd_id]:
                                                data_res_2['result'] = 1
                                                data_res_2['error'] = ""
                                            else:
                                                data_res_2['result'] = 0
                                                data_res_2['error'] = ""


                                            data_res['method'] = "res"
                                            data_res['data'] = data_res_2
                                            msg_2_log = json.dumps(data_res)
                                            # if hostname == "172.16.21.114":
                                            # print(msg_2_log)
                                            status_res_log5 = m1_class.log_action(msg_2_log,"log5","a")
                                            status_res_log1 = m1_class.log_action(msg_2_log,"log1","a")
                                            return_status[cmd_act] = True
                            
                            # tcpconfig(p['ipaddress'],int(p['deviceID']),int(p['port']),3)
                            # start_t = int(time.time())
                            start_reg = 0
                    elif p['mode'].lower() == 'recv':
                        # print(f"RECV on {n} - {p}")
                        start_reg = 0
                        for cmd_id in c:
                            for cmd_act in c[cmd_id]:
                                cml_arr = c[cmd_id][cmd_act]
                                if meterSN in cml_arr:
                                    # print(f'=={cmd_id}=={cml_arr[meterSN]}')
                                    if cmd_act == "recv_holding_rtu":
                                        min_reg = min(cml_arr[meterSN])
                                        max_reg = max(cml_arr[meterSN])
                                        length_485 = int(max_reg - min_reg)+4 if int(max_reg - min_reg)+4 < 125 else 125
                                        path_local = f"{path_fileconfig}/textfile"
                                        local_data_arr = {}
                                        d0_arr_local = {}
                                        # print(f'Model : {rgl[p["model"]]}')
                                        
                                        # print(f"Working on {n} [{meterSN}] - {min_reg},{max_reg} = {len(path_local)}")
                                        if m1_class.ensure_dir_with_perms(path_local, 0o777 ,debug=0):
                                            for filename in os.listdir(path_local):
                                                if filename.endswith('.txt'):
                                                    local_data = m1_class.read_file(path_local + "/" + filename)
                                                    local_data_arr = json.loads(local_data) if m1_class.is_json(local_data) else local_data
                                                    # print("==path Local==",local_data_arr)
                                                    if "mode" in local_data_arr:
                                                        if local_data_arr['mode'] == "status":
                                                            # print("==path Local==",local_data_arr['device_SN'],local_data_arr)
                                                            if local_data_arr['data'] != None:
                                                                # print(local_data_arr['data'])
                                                                if meterSN in local_data_arr['data']:
                                                                    d0_arr_local[meterSN] = local_data_arr['data'][meterSN]
                                                                    # if cmd_id not in m_arr:
                                                                    #     m_arr[cmd_id] = {}
                                                                    # if not meterSN in m_arr[cmd_id]:
                                                                    #     m_arr[cmd_id][meterSN] = {}
                                                                    # m_arr[cmd_id][meterSN] = local_data_arr['data'][meterSN]
                                                                    m_arr[cmd_id] = d0_arr_local
                                                                    print("[{}][{}][RECV] >> {} | {}".format(m1_class.get_current(),m1_class.deviceSN,meterSN,cml_arr[meterSN]))
                                                                    print("[{}][{}][RECV] << {} | {}".format(m1_class.get_current(),m1_class.deviceSN,meterSN,d0_arr_local[meterSN]))
                                                                    
                                                                    data_res = dict()
                                                                    data_res['method'] = "rec" #rec = receive data
                                                                    data_res['data'] = d0_arr_local
                                                                    msg_2_log = json.dumps(data_res)
                                                                    print("====================== LOG ==================================")
                                                                    print(msg_2_log)
                                                                    status_res_log5 = m1_class.log_action(msg_2_log,"log5","a")
                                                                    print("========================================================")
                                                                    if meterSN in m_arr[cmd_id]:
                                                                        local_data_arr["data"].pop(meterSN)
                                                                    print(f'Local data: {local_data_arr["data"]}')
                                                                    m1_class.write_file(path_local + "/" + filename,json.dumps(local_data_arr),"w")
                                                                    
                                                                    # for local_deviceSN in local_data_arr['data']:

                                                                    # if meterSN in d0_arr:
                                                                    #     d0_arr[meterSN].update(local_data_arr['data'][meterSN])
                                                                    # else:
                                                                    #     d0_arr[meterSN] = local_data_arr['data'][meterSN]
                        
                                    # data_res = dict()
                                    # data_res_2 = dict()
                                    
                                    # data_res['method'] = "rec" #rec = receive data
                                    # data_res['data'] = d0_arr
                                    # msg_2_log = json.dumps(data_res)
                                    # print(msg_2_log)
                                    # # status_res_log5 = log_action(msg_2_log,"log5","a")
                    elif p['mode'].lower() == 'cmd':
                        print("=============================================")
                        print(f'====={c}')
                        print("=============================================")
                    
                    
                    if not lasttime_send_status.value:
                        lasttime_send_status.value = 0
                    # print("DIFF====={}".format(int(time.time()) - int(lasttime_send_status.value)))
                    # print("===========Next {} ==================".format(datetime.fromtimestamp(lasttime_send_status.value).strftime("%Y-%m-%d %H:%M:%S")))
                    # print(f'=Type111=={type(dict(m_arr))} == {m_arr}')
                    
                    # //////////////////////////////////////////////////////////////
                    # print("===================================================")
                    # WSData_arr = {}
                    # for outer in m_arr.values():
                    #     for key, val in outer.items():
                    #         WSData_arr.setdefault(key, {}).update(val)
                    
                    # print(f'=====WSData_arr: {WSData_arr}')
                    flag_alarm = 0
                    if "alarm_arr" in global_arr:
                        if 'status_alarm' in global_arr["alarm_arr"]:
                            flag_alarm = global_arr["alarm_arr"]["status_alarm"]
                            print(f'= Status alarm : == {global_arr["alarm_arr"]["status_alarm"]}')
                            # tmp2 = global_arr['alarm_arr']
                            
                            # if int(time.time()) >= int(lasttime_send_status.value) or global_arr["alarm_arr"]["status_alarm"] == 1:
                            #     tmp2['status_alarm'] = 0
                            #     global_arr['alarm_arr'] = tmp2
                            #     print(f'=== Send http : {global_arr["alarm_arr"]}')
                        

                    #     print("===================================================")
                    # //////////////////////////////////////////////////////////////
                    print(f'===[{k}] Before Time send[{int(m1_class.cml_send)}] : {int(time.time())} > {int(lasttime_send_status.value)}')
                    if int(time.time()) >= int(lasttime_send_status.value) or flag_alarm:
                        
                    # if int(time.time()) >= int(lasttime_send_status.value) or True:
                        t_i_m_e = int(m1_class.cml_send)
                        # t_i_m_e = int(10)
                        # lasttime_send_status = int(int(time.time())/t_i_m_e)*t_i_m_e+t_i_m_e
                        # print(f'===t_i_m_e==={lasttime_send_status.value}')
                        # print(f'===t_i_m_e==={t_i_m_e}')
                        lasttime_send_status.value = int(time.time()) +t_i_m_e
                        # print(f'=== After Teime send : {int(lasttime_send_status.value)}')
                        
                        # print(f'===t_i_m_e==={lasttime_send_status.value}')       
                        # print(f'===t_i_m_e==={datetime.fromtimestamp(lasttime_send_status.value).strftime("%Y-%m-%d %H:%M:%S")}')   
                        a1 = dict()
                        d0_arr = dict()
                        status_SI1 = GPIO.input(17)
                        status_SI2 = GPIO.input(27)
                        
                        status_SO1 = GPIO.input(23) #DO0
                        status_SO2 = GPIO.input(24) #DO1
                        status_SO1 = 1 if status_SO1 == 0 else 2
                        status_SO2 = 1 if status_SO2 == 0 else 2
                        d0_arr['SI'] = {'SI1':str(status_SI1),'SI2':str(status_SI2),'RL1':str(status_SO1),'RL2':str(status_SO2)}
                        GPIO.cleanup()
                        if "para" in para_arr:
                            # d0_arr['para'] = para_arr["para"]
                            v_para = {}
                            v_para = para_arr["para"]
                            d0_arr['para'] = dict(v_para)
                            # print(f'===para_arr: {d0_arr}')
                        # d0_arr = d0_arr | para_arr
                        # print(f'=Type=={type(dict(m_arr))} == {m_arr}')
                        
                        if isinstance(dict(m_arr),dict):
                            # print(f'==={m_arr}')
                            for m_cmdid in dict(m_arr):
                                for sn_meter in dict(m_arr)[m_cmdid]:
                                    # print("====sn_meter==={}".format(sn_meter))
                                    if sn_meter in dict(m_arr)[m_cmdid]:
                                        # print("===>> {} === {} == LEN:{}".format(m_cmdid,sn_meter,len(m_arr[m_cmdid][sn_meter])))
                                        if sn_meter in d0_arr:
                                            if isinstance(dict(m_arr)[m_cmdid][sn_meter], dict):
                                                d0_arr[sn_meter].update(dict(m_arr)[m_cmdid][sn_meter])
                                            else:
                                                print("Warning: Cannot update with non-dict:{}".format(type(dict(m_arr)[m_cmdid][sn_meter])))
                                                print("==Data is: {}".format(dict(m_arr)[m_cmdid][sn_meter]))
                                        else:
                                            d0_arr[sn_meter] = dict(m_arr)[m_cmdid][sn_meter]
                        
                        
                                        
                        a1["mode"] = "alarm" if flag_alarm == 1 else "status"
                        a1["device_SN"] = m1_class.deviceSN
                        a1["data"] = d0_arr
                        # if err_arr:
                        #     a1["error"] = err_arr
                        a1["counter"] = str(int(time.time()) - m1_class.time_counter)
                        a1["ts"] = int(time.time())
                        a1["dt"] = datetime.fromtimestamp(int(time.time())).strftime("%Y-%m-%d %H:%M:%S")


                        flag_alarm = 0
                        if not 'alarm_arr' in global_arr:
                            global_arr['alarm_arr'] = {}
                        tmp2 = global_arr['alarm_arr']
                        tmp2['status_alarm'] = 0
                        global_arr['alarm_arr'] = tmp2
                        # clear data
                        # m_arr = dict()  
                        # m_arr.clear()  
                        
                        
                        if m1_class.log_server(json.dumps(a1),"log5","a"):
                            # time_counter = int(time.time())
                            m_arr.clear() 
                        # print(f"=== {a1}")
                        res_http = m1_class.http_send(a1["mode"],  d0_arr, cmd_id="",timeout=3,g_cne=g_cne.value)
                        if res_http[0]:
                            print(f'=== Send Http success {res_http}')
                            if not res_http[1] is None:
                                sec_count = res_http[1]['sec_count'] if 'sec_count' in res_http[1] else 60
                                lasttime_send_status.value = int(time.time()) + sec_count
                                # time_l = lasttime_send_status.value
                                # time_test_cutoff_s = datetime.fromtimestamp(int(time_l))
                                # time_test_cutoff_s = time_test_cutoff_s.strftime("%H:%M:%S")
                                # print(f'Last time == {time_test_cutoff_s}')
                                # print("==================================================")
                                # if 'ms_minus' in res_http[1] and False:
                                #     time_l = lasttime_send_status.value
                                #     time_test_cutoff_s = datetime.fromtimestamp(int(time_l))
                                #     time_test_cutoff_s = time_test_cutoff_s.strftime("%H:%M:%S")
                                #     print(f'Pre time == {time_test_cutoff_s}')
                                #     ms_minus = res_http[1]['ms_minus']
                                #     lasttime_send_status.value = lasttime_send_status.value - ms_minus
                                #     time_l = lasttime_send_status.value
                                #     time_test_cutoff_s = datetime.fromtimestamp(int(time_l))
                                #     time_test_cutoff_s = time_test_cutoff_s.strftime("%H:%M:%S")
                                #     print(f'Last time == {time_test_cutoff_s}')
                                #     print("==================================================")
                                if 'cne' in res_http[1]:
                                    g_cne.value = res_http[1]['cne'].encode('utf-8')
                                    
                        else:
                            print(f"=== Send Http Error ")
                    # print(m_arr)            
                # else:
                #     print(f"Working on {n} - {p}")

        except Exception as e:
            print(f'Error as {e}')
                
def Process_CMA(resCMA,devicelist,registerlist,lasttime_send_status,m_arr,g_cne,para_arr):
    print("===Core 1 =====")
    #  {"mode":"cmd","data":{"uploadfile":{"src":"dlog/M117585323744150/M117585323744150_log5_202509241115.txt","dst":"dlog/M117585323744150/M117585323744150_log5_202509241115.txt"}}}
    # print(f'===={resCMA}') # output: ===={'C1728370820091': {'cmd': {'PM210001': {'p_t': {'read': 1}}}}}
    # print(f'===={registerlist}')
    while True:
        try:
            resCMA = json.loads(m1_class.read_file('cma.json')) if m1_class.is_json(m1_class.read_file('cma.json')) else {}
            # continue
            # break
        
            for cma_id in resCMA:
                print(f'>> Pre: {resCMA}')
                
                # print(f'core 04 [{cma_id}]: {resCMA}')
                
                for cma_act in resCMA[cma_id]:
                    
                    # print(f'core 04 [{dfl_id}][{dfl_act}]: {resDFL[dfl_id][dfl_act]}')
                    if cma_act == "cmd":
                        cma_data_arr = {}
                        cma_status_arr = {}
                        start_t = int(time.time())
                        for cma_devicesn in resCMA[cma_id][cma_act]:
                            # print(f'=={cma_id}=={dev_sn}')
                            # print(f'==={devicelist[dev_sn]}')
                            if cma_devicesn in devicelist:
                                cma_model = devicelist[cma_devicesn]['model']
                                cma_mode = devicelist[cma_devicesn]['mode']
                                cma_deviceID = int(devicelist[cma_devicesn]['deviceID'])
                                if cma_mode.lower() == 'tcp':
                                    cma_ip = devicelist[cma_devicesn]['ipaddress']
                                    cma_port = int(devicelist[cma_devicesn]['port'])
                                    rgl_model = registerlist[cma_model]
                                    # print(f'====={rgl_model}')
                                    # print(f'==connect by {cma_mode} : == {cma_ip}:{cma_port}')
                                    instrument = m1_class.tcpconfig(cma_ip,cma_deviceID,cma_port,1)
                                    if instrument.open():
                                        for  cma_para in resCMA[cma_id][cma_act][cma_devicesn]:
                                            for reg, info in rgl_model.items():
                                                if info.get("name") == cma_para:
                                                    
                                                    act_keys = next(iter(resCMA[cma_id][cma_act][cma_devicesn][cma_para].keys()))
                                                    act_values = next(iter(resCMA[cma_id][cma_act][cma_devicesn][cma_para].values()))
                                                    # print(f'Para is : {act_keys}')
                                                    # print(f'Para is : {reg}')
                                                    # resCMA[cma_id][cma_act][cma_devicesn]
                                                    
                                                    if not cma_devicesn in cma_data_arr:
                                                        cma_data_arr[cma_devicesn] = {}
                                                    if not cma_para in cma_data_arr[cma_devicesn]:
                                                        cma_data_arr[cma_devicesn][cma_para] = {}
                                                    
                                                    if act_keys.lower() == 'read':
                                                        data_mb_read = m1_class.readmodbustcp(instrument,int(reg),int(2),3)
                                                        data_read = {}
                                                        if "data" in data_mb_read:
                                                            data_read = json.loads(data_mb_read['data']) if m1_class.is_json(data_mb_read['data']) else ast.literal_eval(data_mb_read['data'])
                                                            data_command = m1_class.convert_data(data_read,rgl_model,int(reg))
                                                            cma_data_arr[cma_devicesn][cma_para] = data_command[cma_para]
                                                    if act_keys.lower() == 'write':
                                                        # print(f'==={act_values}')
                                                        # print(f'==={info.get("multiply")}')
                                                        # print(f'==={int(float(act_values)/float(info.get("multiply")))}')
                                                        cma_data_dst = round(float(act_values)/float(info.get("multiply")))
                                                        icc=0
                                                        while icc < 3:
                                                            icc+=1
                                                            print("====SS Write485_{}_{}_success==write:{}===".format(cma_id,cma_devicesn,cma_data_dst))
                                                            
                                                            # print(f'==={cma_id} == {resCMA[cma_id]}')
                                                            
                                                            if m1_class.writemodbustcp(instrument,int(reg),int(cma_data_dst),1):
                                                                print("====SSSSSSSS{}uccess==write:{}===".format(cma_devicesn,cma_data_dst))
                                                                icc=3
                                                                time.sleep(1)
                                                                cma_status_arr[cma_devicesn] = 1
                                                                data_mb_read = m1_class.readmodbustcp(instrument,int(reg),int(2),3)
                                                                data_read = {}
                                                                if "data" in data_mb_read:
                                                                    data_read = json.loads(data_mb_read['data']) if m1_class.is_json(data_mb_read['data']) else ast.literal_eval(data_mb_read['data'])
                                                                    data_command = m1_class.convert_data(data_read,rgl_model,int(reg))
                                                                    cma_data_arr[cma_devicesn][cma_para] = data_command[cma_para]
                                                            else:
                                                                print("==Command not found!!!")
                                                                cma_status_arr[cma_devicesn] = 0
                                                                time.sleep(2)
                                                        # data_mb_read = readmodbustcp(instrument,int(reg),int(2),3)
                                                        # data_read = {}
                                                        # if "data" in data_mb_read:
                                                        #     data_read = json.loads(data_mb_read['data']) if m1_class.is_json(data_mb_read['data']) else ast.literal_eval(data_mb_read['data'])
                                                        #     data_command = convert_data(data_read,rgl_model,int(reg))
                                                        #     cma_data_arr[cma_devicesn][cma_para] = data_command[cma_para]
                                                        
                                                    
                                        # print(f'==connect by {cma_mode} : == {cma_ip}:{cma_port}//[{cma_deviceID}]====Data: [{cma_data_arr}]')
                                        print(f'=============================================================================')
                                    time.sleep(1)
                            
                            elif cma_devicesn == "para":
                                # print(f'====para: {resCMA[cma_id][cma_act][cma_devicesn]}')
                                for cma_para in resCMA[cma_id][cma_act][cma_devicesn]:
                                    if "write" in resCMA[cma_id][cma_act][cma_devicesn][cma_para]:
                                        val_para = resCMA[cma_id][cma_act][cma_devicesn][cma_para]["write"]
                                        # print(f'====para2: {type(para_arr)}')
                                        temp = para_arr['para']
                                        temp['para1'] = val_para
                                        para_arr['para'] = temp
                                    
                            # else:
                            #     if cma_devicesn == "para":
                            #         for cmd_params in resCMA[cma_id]:
                            #             print(f'====para: {resCMA[cma_id][cmd_params]}')
                                        # if cma_devicesn in resCMA[cma_id][cmd_params]:
                                        #     print(f'====para: {cma_devicesn}==={cmd_params} ==== {resCMA[cma_id][cma_devicesn]}')
                                        
                                        #     if "write" in resCMA[cma_id][cmd_params][cma_devicesn]:
                                        #         # val_para = int(resCMA[cma_id][cmd_params][cma_devicesn][cma_devicesn]["write"])
                                        #         # print(f'====para2: {val_para}')

                                        #         # para_arr[cma_devicesn][cmd_params] = str(val_para)
                                        #         # print(f'====para_arr:{para_arr}')
                                        #         # # para_arr['para']['para1'] = str(val_para)
                                        #         # para = para_arr['para']

                                        #         # para[cma_devicesn][cmd_params]=str(val_para)
                                        #         # para_arr = para
                                        #         # print(f'====para_arr2:{para_arr["para"]}')

                                                
                                        #         data_command[cmd_params] = 0
                                        #         data_device_cmd[cma_id] = {cma_devicesn:data_command}
                                        #     # elif "read" in resCMA[cma_id][cmd_params]:
                                        #     #     # val_para = int(resCMA[cmd_reply][cmd_params]["read"])
                                        #     #     data_device_cmd[cma_id] = para_arr
                                        #     # elif "set" in resCMA[cma_id][cmd_params]:
                                        #     #     val_para = resCMA[cma_id][cmd_params]["set"]
                                        #     #     para_arr[cma_id][cmd_params] = str(val_para)
                                        #     #     data_command[cmd_params] = str(val_para)
                                        #     #     data_device_cmd[cma_id] = {cma_id:data_command}
                                
                                # if cma_devicesn == "RL" or cma_devicesn == "SI":
                                #     # print(f'===== WRITE GPIO : {resCMA}')
                                #     for cmd_params in resCMA[cma_id]:
                                #         print(resCMA[cma_id])
                                #         map_rgl_2io = {}
                                #         map_rgl_2io['RL1'] = 23 #DO0
                                #         map_rgl_2io['RL2'] = 24 #DO1
                                #         # if cmd_params in map_rgl_2io:
                                #         #     print(f'==={cmd_params}==={map_rgl_2io[cmd_params]} ==== {cml_arr[cmd_reply]}')
                                        
                                #         if cmd_params in resCMA[cma_id]:
                                #             # print(f'===={cmd_params}')
                                #             if cmd_params in resCMA[cma_id]:
                                #                 if "write" in resCMA[cma_id][cmd_params]:
                                #                     val_spc = int(resCMA[cma_id][cmd_params]["write"])
                                #                     if val_spc == 2:
                                #                         GPIO.output(int(map_rgl_2io[cmd_params]), GPIO.HIGH)
                                #                     if val_spc == 1:
                                #                         GPIO.output(int(map_rgl_2io[cmd_params]), GPIO.LOW)
                                                        
                                #                     print(f'={cma_id}=={cmd_params}==={map_rgl_2io[cmd_params]} ==== {GPIO.input(int(map_rgl_2io[cmd_params]))}')
                                #                     # data_command[cmd_params] = str(GPIO.input(int(map_rgl_2io[cmd_params])))
                                #                     data_command[cmd_params] = str(val_spc)
                                #                     data_device_cmd[cma_id] = {cma_id:data_command}
                                #                 elif "read" in resCMA[cma_id][cmd_params]:
                                #                     # data_command[cmd_params] = str(GPIO.input(int(map_rgl_2io[cmd_params])))
                                #                     val_spc = int(resCMA[cma_id][cmd_params]["read"])
                                #                     data_command[cmd_params] = str(val_spc)
                                #                     data_device_cmd[cma_id] = {cma_id:data_command}
                                                    
                                #                 elif "set" in resCMA[cma_id][cmd_params]:
                                #                     val_spc = int(resCMA[cma_id][cmd_params]["set"])
                                #                     data_command[cmd_params] = str(val_spc)
                                #                     data_device_cmd[cma_id] = {cma_id:data_command}
                                    
                                
                        
                        # cml_arr = resCMA[cma_id][cma_act]
                        # log_dir = os.path.dirname(__file__)
                        # logdirNames = os.path.join(log_dir, "log_action/"+str(deviceSN)+"/")
                        # time_interval = cml_arr['time_interval'] if "time_interval" in cml_arr else 1
                        # time_offset = cml_arr['time_offset'] if "time_offset" in cml_arr else 0
                        # print(f'==={time_interval} ==== {time_offset} ==== {lasttime_log5.value}')
                        
                        # Ex. {"mode": "reply", "device_SN": "M117289601136254", "cmdid": "C1758689231170", "data": {"IN205011": {"p_max": "100.0"}}, "ts": 1758689234}
                        # {"mode": "reply", "device_SN": "M117585323744150", "cmdid": "C1728370820091", "data": {"PM210001": {"p_t": "446.416", "e_p": "1521325.056"}}, "ts": 1758689787}
                        # a1 = {}
                        # a1["mode"] = "reply"
                        # a1["device_SN"] = deviceSN
                        # a1["cmdid"] = cma_id
                        # a1["data"] = cma_data_arr
                        # a1["ts"] = int(time.time())
                        
                        data_device_cmd = {}
                        if not cma_id in data_device_cmd:
                            data_device_cmd[cma_id] = {}
                            
                        # if cma_data_arr != {}:
                        #     data_device_cmd[cma_id] = cma_data_arr
                        
                        msg_txt = {}
                        # print(f'Send ====HTTP ==== {json.dumps(a1)}')
                        # print(f'Send ====HTTP ==== {cma_data_arr}')
                        if cma_id in data_device_cmd:
                            msg_txt['mode'] = cma_act
                            msg_txt['result'] = cma_status_arr[cma_devicesn]
                            msg_txt['text'] = resCMA[cma_id][cma_act]
                            # res_http = http_send('reply',  data_device_cmd[cma_id], cmd_id=cma_id,timeout=3,g_cne=g_cne.value)
                            res_http = m1_class.http_send('reply',  msg_txt, cmd_id=cma_id,timeout=3,g_cne=g_cne.value)
                            if res_http[0]:
                                print(f'=== Send Http success {res_http[1]}')
                        # print(f'end check : {resCMA}')
                        # if cma_id in resCMA:
                        #     del resCMA[cma_id]
                        # m1_class.write_file('cma.json',json.dumps(resCMA),'w')
                        print(f'===========================cccc485=================================================')          
                    if cma_act == "restart":
                        print(cma_act)
                        
                    print(f'end check : {resCMA}')
                    if cma_id in resCMA:
                        del resCMA[cma_id]
                    m1_class.write_file('cma.json',json.dumps(resCMA),'w')
        except Exception as e:
            print(f'===={e}')   
            pass             
    
def Process_mqtt(ts_cmd,time_hb,g_cne):
    # global mqttc
    try:
        mqttc = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2)
        mqttc.on_connect = m1_class.on_connect
        mqttc.on_message = m1_class.on_message
        mqttc.connect(m1_class.mqttBroker, int(m1_class.mqttPort), 60)
        mqttc.loop_forever()
        # 172.16.8.230
        # rel.timeout(10,hh)
        # rel.signal(2, rel.abort)  # Keyboard Interrupt
        # rel.dispatch()
    except Exception as e:
        print(f'process 3 error {e}')

def Process_checkws(ts_cmd,time_hb,g_cne):
    # global ts_cmd
    # global g_cne
    # global mqttc
    # global last_send2api
    # print(f'===HB Time: {time_hb.value}')
    print(f'===g_cne: {g_cne.value}')
    # time_count_1s = 0
    ts_cmd.value = int(time.time())
    # last_action = time.time()
    # time_hb = 0
    last_send2api = 0
    debug_ = False
    while True:
        try:
                
            # print("==time_hb",time_hb)
            # now = time.time()
            # if now - last_action >= 1:
            #     print("==diff time ==="+str(int(time.time()))+" - "+str(ts_cmd.value)+" = "+str(int(int(time.time())-int(ts_cmd.value))))
            #     last_action = now
            
            if int(time.time()) - time_hb.value >= 60:
                print("==time_hb",time_hb.value)
                
                time_hb.value = int(time.time())
                msg_txt = {}
                msg_txt['ip'] = m1_class.get_ipv4_from_nic("eth0")
                msg_txt['ipvpn'] = m1_class.get_ipv4_from_nic("tun0")
                
                m1_class.http_send('check_ws', msg_input=msg_txt, cmd_id="")
                # a1 = {}
                # a1["mode"] = "check_ws"
                # a1["device_SN"] = deviceSN
                # a1["data"] = ""
                

                
                # a1["ip"] = m1_class.get_ipv4_from_nic("eth0")
                # a1["ipvpn"] = m1_class.get_ipv4_from_nic("tun0")

                # ts_e = int(time.time())
                # a1["ts"] = ts_e

                # # print(a1)
                # diff_cmd = int(int(time.time())-int(ts_cmd.value))
                # print("==diff time ==="+str(int(time.time()))+" - "+str(ts_cmd.value)+" = "+str(diff_cmd))
                # print(a1)
                
                # httpSend = requests.post("http://api.mdbiot.com/vx_mdbiot_api.php"+"?device_sn="+deviceSN,data={"mode":"WSDevice","WSData": json.dumps(a1)},headers={"User-Agent": "INNO/2025","cne":g_cne.value},verify=False,timeout=3)
                # # if httpSend.status_code == 200:
                # if debug_ == True:
                #     print("[{}][{}][http][check_ws] >> server | {}".format(m1_class.get_current(),deviceSN,json.dumps(a1)))
                # if httpSend.status_code == 200:
                #     # print("===httpSend=="+str(httpSend.text))
                #     g_cne_arr = json.loads(httpSend.text) if m1_class.is_json(httpSend.text) else {}
                #     # if g_cne_arr != {}:
                #         # ms_minus = int(g_cne_arr['ms_minus']) if 'ms_minus' in g_cne_arr else 0
                #         # g_cne = g_cne_arr['cne'] if 'cne' in g_cne_arr else ''
                #         # sec_send = g_cne_arr['sec_send'] if 'sec_send' in g_cne_arr else ''
                #         # print("====================================================================")
                #         # print("===g_cne=="+str(g_cne))
                #         # print("===ms_minus=="+str(ms_minus))
                #         # print("===sec_send=="+str(sec_send))
                #         # print("====================================================================")
                #     if debug_ == True:
                        
                #         print("[{}][{}][http][check_ws] << server | {}".format(m1_class.get_current(),deviceSN,httpSend.text))

                    
                # if diff_cmd > 120 and diff_cmd != int(time.time()):
                #     ts_cmd.value = int(time.time())
                #     # os.system("pm2 restart all")

            # if time.time() - ts_cmd > 120:
            #     # os.system("pm2 restart all")
            #     print("pm2 restart all")
            # hh()
            # time.sleep(2)
        except Exception as e:
            print(e)

def Process_defaultlist(resDFL,lasttime_log5,lasttime_clear_log,last_clear_log,last_clear_log5_data,last_clear_log_event):
    # global devicelist,registerlist
    # print(f'core 04 : {resDFL}')
    while True:
        try:

            for dfl_id in resDFL:
                # print(f'core 04 [{dfl_id}]: {resDFL[dfl_id]}')
                for dfl_act in resDFL[dfl_id]:
                    
                    # print(f'core 04 [{dfl_id}][{dfl_act}]: {resDFL[dfl_id][dfl_act]}')
                    if dfl_act == "updatelog":
                        start_t = int(time.time())
                        
                        cml_arr = resDFL[dfl_id][dfl_act]
                        log_dir = os.path.dirname(__file__)
                        logdirNames = os.path.join(log_dir, "log_action/"+str(m1_class.deviceSN)+"/")
                        time_interval = cml_arr['time_interval'] if "time_interval" in cml_arr else 1
                        time_offset = cml_arr['time_offset'] if "time_offset" in cml_arr else 0
                        # print(f'==={time_interval} ==== {time_offset} ==== {lasttime_log5.value}')
                        if lasttime_log5.value == 0:
                            lasttime_log5.value = int(int(time.time()/time_interval)*time_interval) + time_interval + time_offset
                            print("updatelog===Next Time {}".format(str(datetime.fromtimestamp(lasttime_log5.value))))
                            # print("time log5",lasttime_log5)
                        elif int(start_t) > int(lasttime_log5.value):
                            # print(lasttime_log5)
                            cmd_id_dev = "M"+str(int(time.time()*1000000))
                            # log_device(mlog_device+"|OK","device","a")

                            lasttime_log5_str = datetime.fromtimestamp(lasttime_log5.value)
                            time_log5_date = lasttime_log5_str.strftime("%Y%m%d%H%M")
                            time_log5_date_22 = lasttime_log5_str.strftime("%Y%m%d")

                            ts_ep_log5 = int(int(time.time())/300)*300
                            time_ep_log5 = datetime.fromtimestamp(ts_ep_log5)
                            time_ep_log5_date = time_ep_log5.strftime("%Y%m%d%H%M")
                            time_ep_log5_date_tt = time_ep_log5.strftime("%Y%m%d")
                            # print("2=Next Time ")
                            lasttime_log5.value = int(int(time.time()/time_interval)*time_interval) + time_interval + time_offset
                            filename_log5_txt5 = str(m1_class.deviceSN)+"_log5_"+str(time_log5_date)
                            # print("==== Filename =====",filename_log5_txt5)
                            if m1_class.ensure_dir_with_perms(logdirNames, 0o777 ,debug=0):
                                pass
                            file = os.listdir(logdirNames)
                            file.sort(reverse=False)
                            # print(":::::::::est001==",time_ep_log5_date)
                            for ifile in file:
                                # if "log5_" in ifile and time_ep_log5_date_tt in ifile:
                                if "log5_" in ifile :
                                    fname = ifile[:ifile.find('.')].split(str(m1_class.deviceSN)+'_log5_')
                                    file_ts2 = fname[1][:len(fname[1])]
                                    file_ts2_d4 = fname[1][:len(fname[1])-4]
                                    
                                    if int(file_ts2) < int(time_log5_date) or int(file_ts2_d4) < int(time_log5_date_22):
                                        # print(file_ts2,time_log5_date,ifile)
                                        if ".txt" in ifile:
                                            # print(file_ts2_d4,time_log5_date,ifile)
                                            # print("===========================xxxx==========================")
                                            file_name = ifile[:ifile.find('.')]
                                            if not os.path.isfile(os.path.dirname(__file__)+"/log_action/"+m1_class.deviceSN+"/"+file_name+".zip"):
                                                print(logdirNames+file_name+".txt")
                                                # cmd_id_dev = "M"+str(int(time.time()*1000000))
                                                if m1_class.zip_file(logdirNames+file_name+".txt"):
                                                    print(logdirNames+file_name+'.zip')
                                if "log1_" in ifile :
                                    fname = ifile[:ifile.find('.')].split(str(m1_class.deviceSN)+'_log1_')
                                    file_ts2 = fname[1][:len(fname[1])]
                                    file_ts2_d4 = fname[1][:len(fname[1])-4]
                                    
                                    if int(file_ts2) < int(time_log5_date) or int(file_ts2_d4) < int(time_log5_date_22):
                                        # print(file_ts2,time_log5_date,ifile)
                                        if ".txt" in ifile:
                                            # print(file_ts2_d4,time_log5_date,ifile)
                                            # print("===========================xxxx==========================")
                                            file_name = ifile[:ifile.find('.')]
                                            if not os.path.isfile(os.path.dirname(__file__)+"/log_action/"+m1_class.deviceSN+"/"+file_name+".zip"):
                                                print(logdirNames+file_name+".txt")
                                                # cmd_id_dev = "M"+str(int(time.time()*1000000))
                                                if m1_class.zip_file(logdirNames+file_name+".txt"):
                                                    print(logdirNames+file_name+'.zip')
                
                    if dfl_act == "clearlog5":
                        start_t = int(time.time())
                        cml_arr = resDFL[dfl_id][dfl_act]
                        path_err = os.path.dirname(__file__)+'/dlog/'+m1_class.deviceSN
                        res_cl5 = m1_class.clear_log5_data(path_err,cml_arr,last_clear_log5_data.value)
                        if res_cl5[0]:
                            last_clear_log5_data.value = res_cl5[1]
                            # print(f'clear_log5_data==[{last_clear_log5_data.value}] === {cml_arr}')
                        # else:
                        #     print(f'clear_log5_data==[{last_clear_log5_data.value}] === XXXX')
                            
                            # log_device("dlog|OK","device","a")
                        
                    if dfl_act == "clearlogevent":
                        start_t = int(time.time())
                        cml_arr = resDFL[dfl_id][dfl_act]
                        path_err = os.path.dirname(__file__)+'/log_err/'+m1_class.deviceSN
                        res_clerr = m1_class.clear_log_event(path_err,cml_arr,last_clear_log_event.value)
                        if res_clerr[0]:
                            last_clear_log_event.value = res_clerr[1]
                            print(f'clear_log_event==[{last_clear_log_event.value}] === {cml_arr}')
                        # else:
                        #     print(f'clear_log5_data==[{last_clear_log5_data.value}] === XXXX')
                            
                            # log_device("dlog|OK","device","a")
                    
                    if dfl_act == "checkinternet":
                        cml_arr = resDFL[dfl_id][dfl_act]
                        m1_class.check_internet()   
                    if dfl_act == "clearlogfile":
                        start_t = int(time.time())
                        cml_arr = resDFL[dfl_id][dfl_act]
                        path_logs = os.path.dirname(__file__)+'/log_action/'+m1_class.deviceSN
                        # print(f'====Clear log file // {path_logs}')
                        # print("========================================xxxxxx=========")
                        # res_clf = clear_log_file(cml_arr,lasttime_clear_log.value)
                        res_clf = m1_class.clear_log_file(path_logs,cml_arr,lasttime_clear_log.value)
                        if res_clf[0]:
                            lasttime_clear_log.value = res_clf[1]
                            print("clearlogfile=======",res_clf[1])
                            
                    #         # log_device(mlog_device+"_data|OK","device","a")

                    #     # if clear_log(path_logs,cml_arr,last_clear_log.value):
                    #     #     # log_device(mlog_device+"_device|OK","device","a")
                    #     #     pass
                
        except Exception as e:
            print(f'Except process4 is {e}')
            
def Process_99(ts_cmd,time_hb,g_cne):
    while True:
        try:
            print(f'=======status_vpn: {m1_class.status_vpn} =======')
            time.sleep(1)
        except Exception as e:
            pass
        # try:
        #     # print("===status_vpn==",status_vpn)
        #     if status_vpn == 1:
        #         print("connect VPN")
        #         if get_ipv4_from_nic("tun0") != None:
        #             os.system("sudo killall openvpn")
        #         # /home/pi/Desktop/python/VPN/VPN
        #         subprocess.Popen("python3 /home/pi/ptest/zrunvpn.py", shell=True)
        #         # subprocess.Popen("sudo openvpn --config ~/python/VPN/VPN.ovpn", shell=True)
        #         status_vpn = 2
        #         ts_vpn = time.time()
                

        #     if status_vpn == 2:
        #         tsnow_vpn = time.time()
        #         if int(tsnow_vpn) - int(ts_vpn) >= 5 :
        #             a1 = dict()
        #             # a1["mode"] = "reply"
        #             a1["ipvpn"] = get_ipv4_from_nic("tun0")

        #             mqttc3 = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2)
        #             mqttc3.connect("mqtt.mdbiot.com", 1883, 60)
        #             mqttc3.publish("meow/"+deviceSN, json.dumps(a1))
        #             mqttc3.publish("res/"+deviceSN, json.dumps(a1))
        #             # mqttc3.disconnect()
        #             print("Send MQTT===")
        #             status_vpn = 3

        #             mqttc = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2)
        #             mqttc.on_connect = on_connect
        #             mqttc.on_message = on_message
        #             mqttc.connect("mqtt.mdbiot.com", 1883, 60)
        #             mqttc.loop_forever()
        # except Exception as e:
        #     pass           
            
if __name__ == "__main__":
        
    # ////////////////////// Setup //////////////////////
    GPIO.setwarnings(False)
    GPIO.setmode(GPIO.BCM)  # Use BCM pin numbering
    GPIO.setup(17, GPIO.IN)  # Set +11,-09 ,DI0
    GPIO.setup(27, GPIO.IN)  # Set +15,-13 ,DI1

    GPIO.setup(23, GPIO.OUT) 
    GPIO.setup(24, GPIO.OUT) 
    
    # ////////////////////////////////////////////////////////
    watchdog_time = 0

    # ////////////////////// init class //////////////////////
    m1_class            = main_m1()
    m1_class_custom1    = m1_custom1()
    # m1_class_2 = main_m1()
            
    # ////////////////////// key encrypt aes-128 //////////////////////
    key             = "inno2024"
    iv              = ""
    # ////////////// Path config & webserver //////////////////
    path_fileconfig = '/var/www/html/meow'
    # ////////////////////// Variable start //////////////////
    path_def = f'{path_fileconfig}/data/mcf_default.json'
    main_txt = m1_class.read_file(path_def)
    main_txt_arr    = json.loads(main_txt) if m1_class.is_json(main_txt) else {}
    # ////////////////////// custom set variable //////////////////////
    main_txt_arr['status_vpn']  = 0
    main_txt_arr['path_def']    = path_def
    main_txt_arr['time_counter'] = int(time.time())
    main_txt_arr['g_cne'] = 'cVpWUUl6ZGR1QUUxRy9XL1lWYWpiN1lPSUIzZE9YUmRHdTJtT1ZqK2c5bz0='
    # ////////////////////// use class //////////////////////
    m1_class = main_m1(main_txt_arr)
    m1_class.show()
    
    # q = Queue()
    lock = Lock()
    manager = Manager()
    
    # //////////////////////////////////////////////////////////////////////////////////////////////

    processes = []
    devicelist = m1_class.read_file(f'{path_fileconfig}/config/dvl.json')
    registerlist = m1_class.read_file(f'{path_fileconfig}/config/rgl.json')
    resCML = m1_class.read_file(f'{path_fileconfig}/config/cml.json')
    resDFL = m1_class.read_file('dfl.json')
    resCMA = m1_class.read_file('cma.json')
    
    # lasttime_send_status = int(time.time())
    lasttime_send_status    = Value('d', 0)  # 'd' = double (float)
    lasttime_log5           = Value('i', 0)
    lasttime_clear_log      = Value('i', 0)
    last_clear_log          = Value('i', 0)
    last_clear_log5_data    = Value('i', 0)
    last_clear_log_event    = Value('i', 0)
    
    m_arr       = manager.dict()
    global_arr  = manager.dict()
    para_arr    = manager.dict({"para":{"para1": "0"}})
    
    ts_cmd  = Value('i', 0)
    time_hb = Value('i', 0)
    g_cne   = Value(c_char_p, b"cVpWUUl6ZGR1QUUxRy9XL1lWYWpiN1lPSUIzZE9YUmRHdTJtT1ZqK2c5bz0=")
    
    #  ////////////////////// array list //////////////////////
    actionlist_arr  = json.loads(resCMA) if m1_class.is_json(resCMA) else {}
    defaultlist_arr = json.loads(resDFL) if m1_class.is_json(resDFL) else {}
    devicelist_arr  = json.loads(devicelist) if m1_class.is_json(devicelist) else {}
    registerlist_arr = json.loads(registerlist) if m1_class.is_json(registerlist) else {}
    # ////////////////////// Process all //////////////////////
    p1 = Process(target=Process_CMA, args=(actionlist_arr,devicelist_arr,registerlist_arr,lasttime_send_status,m_arr,g_cne,para_arr,))
    p1.start()
   
    p2 = Process(target=Process_mqtt, args=(ts_cmd,time_hb,g_cne,))
    p2.start()
    
    p3 = Process(target=Process_checkws, args=(ts_cmd,time_hb,g_cne,))
    p3.start()
   
    # Default list command 
    p4 = Process(target=Process_defaultlist, args=(defaultlist_arr,lasttime_log5,lasttime_clear_log,last_clear_log,last_clear_log5_data,last_clear_log_event,))
    p4.start()
    
    # process VPN 
    # p99 = Process(target=Process_99, args=(ts_cmd,time_hb,g_cne))
    # p99.start()
    
    m_custom_txt = {}
    
    while True:
        try:
            m1_class.write_file('m1_timestamp.txt',str(int(time.time())),"w")
            
            devicelist = m1_class.read_file(f'{path_fileconfig}/config/dvl.json')
            # print(f'len : {len(json.loads(devicelist))}')
            registerlist = m1_class.read_file(f'{path_fileconfig}/config/rgl.json')
            resCML = m1_class.read_file(f'{path_fileconfig}/config/cml.json')
            # ////////////////////////////////////////////////////////////////////////////////////////////////////////
            # custom variable
            m_custom_txt['devicelist'] = devicelist
            m_custom_txt['registerlist'] = registerlist
            m_custom_txt['resCML'] = resCML
            m_custom_txt['start_time'] = int(time.time())
            m_custom_txt['para_arr'] = para_arr
            
            m1_class_custom1 = m1_custom1(m_custom_txt)
            # m1_class_custom1.show()
            
            # /////////////////////// array list ///////////////////////
            devicelist_arr = json.loads(devicelist) if m1_class.is_json(devicelist) else {}
            commandlist_arr = json.loads(resCML) if m1_class.is_json(resCML) else {}
            registerlist_arr = json.loads(registerlist) if m1_class.is_json(registerlist) else {}
            # ////////////////////////////////////////////////////////////////////////////////////////////////////////
            start_time = int(time.time())
            # print(devicelist_arr)
            # print(commandlist_arr)
            
            # /////////////////// ทำให้วนลูปตามจำนวน device ของชุดคำสั่งที่ต้องการ ///////////////////
            unique_meter_ids = list({
                meter
                for session in commandlist_arr.values()
                for cmd in session.values()
                for meter in cmd
            })
            print(f'==== meter_ids: {unique_meter_ids}')
            # ////////////////////////////////////////////////////////////////////////////////////////////////////////
            
            # for k,dvl in enumerate(json.loads(devicelist)):
            #     print(dvl)
            time_t1 = int(time.time())
            processes = []

            for k,dvl in enumerate(unique_meter_ids):
                m1_class.write_file('m1_timestamp.txt',str(int(time.time())),"w")
                # print(dvl)
                # print(json.loads(devicelist)[dvl])
                if not dvl in devicelist_arr:
                    continue
                p = Process(target=worker, args=(lock,k,devicelist_arr[dvl],commandlist_arr,dvl,registerlist_arr,lasttime_send_status,m_arr,g_cne,para_arr,global_arr,manager,))
                # processes.append(p)
                p.start()
                p.join()
                # if p.is_alive():
                #     print("Worker frozen or timeout → terminating")
                #     p.terminate()     # kill the process
                #     p.join()
                p.close()  # ensure resources released
                # time.sleep(5)
                
                print(f'==Time ddd : {int(time.time()) - time_t1}')
                
            # ////////////////////////////////////////////////////////////////////////////////////////////////////////
            # print(processes)
            
            # for p in processes:
            #     p.join()
            # special_proc.join()
            
            # ////////////////////////////////////////////////////////////////////////////////////////////////////////
            # use module custom 
            # m1_class_custom1.inverter_automation(m_arr.values())
            # ////////////////////////////////////////////////////////////////////////////////////////////////////////
            print('==================================================================')
            print(f'All workers finished is [{str(int(time.time())-start_time)}s]')
            print(f'=== watchdog timmer : {time.time()}')
            
            
            # time.sleep(1)
        except Exception as e:
            print(f'Error as {e}', file=sys.stderr)
            if e.errno == 24:
                # os.system("sudo ulimit -n 4096")
                # os.system("")
                print(e)
            # else:
            #     raise  # re-raise other OS errors
            
            # Log the error (PM2 reads stderr)
            # print("[ERROR] Unhandled exception:", file=sys.stderr)
            # print(traceback.format_exc(), file=sys.stderr)
            
            # Optional: slow down restart loop to avoid 100% CPU
            # time.sleep(2)
            # Exit with non-zero → PM2 restarts the app
            # sys.exit(1)
            
        # finally:
        #     # Cleanup GPIO pins
        #     GPIO.cleanup()
            
    
    
# ///////// NOTE //////////////////
# pm2 start main.py \
#   --name meter_app \
#   --interpreter python3 \
#   --restart-delay 2000 \
#   --max-memory-restart 200M \
#   --max-restarts 20