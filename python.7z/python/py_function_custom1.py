import json
import time
from datetime import datetime
import re

from py_function_inc1 import main_m1

class m1_custom1:
    def __init__(self, json_input={}):
        self.main_m1_ini = main_m1()
        # Automatically set each key as an instance attribute
        for key, value in self._validate_json(json_input).items():
            # print(f"{key}: {value}")
            setattr(self, key, value)
        self.serial_port_rs485 = '/dev/ttyACM0'
        
    def show(self):
        for key, value in self.__dict__.items():
            print(f"{key}: {value}")
         
    def _validate_json(self, json_input):
        """Check if input is valid JSON and return as dict."""
        if json_input is None:
            return {}
        
        if isinstance(json_input, dict):
            # Already a Python dict, fine
            return json_input
        elif isinstance(json_input, str):
            try:
                return json.loads(json_input)
            except json.JSONDecodeError:
                raise ValueError("Invalid JSON string")
        else:
            raise TypeError("Input must be a JSON string or dict")
   
    def inverter_automation(self, m_arr):
        try:
            print("===================================================")
            now_time = datetime.now().strftime("%H%M")
            if True and "0730" <= now_time <= "1730":
                # your code here
                WSData_arr = {}
                for outer in m_arr:
                    for key, val in outer.items():
                        WSData_arr.setdefault(key, {}).update(val)
                
                # print(f'=====WSData_arr: {WSData_arr}')
                p_arr = WSData_arr
                if 'PM210001' in p_arr:
                    if 'p_t' in p_arr['PM210001']:
                        IN_arr = [in_key for in_key in p_arr if in_key in p_arr and re.search(r'IN', in_key)]
                        p_max_arr = {"IN159012": 50,"IN159013": 50,"IN159014": 50,"IN204010": 100,"IN205011": 100,"IN206012": 100,"IN207013": 100,"IN208011": 100,"IN203001": 100}
                        p_PM = round(float(p_arr['PM210001']['p_t']),2)

                        print(f'===p_para: {p_PM}')
                        # print(f'===IN_arr: {IN_arr}')
                        dvl_arr = json.loads(self.devicelist)
                        rgl_arr = json.loads(self.registerlist)
                        # print(f'===DVL: {dvl_arr}')
                        # print(f'===p_max_arr: {p_max_arr}')
                        sum_IN = 0
                        
                        for i_IN, this_IN in enumerate(IN_arr):
                            dvl_model = dvl_arr[this_IN]['model']
                            dvl_ip = dvl_arr[this_IN]['ipaddress']
                            dvl_port = dvl_arr[this_IN]['port']
                            dvl_id = dvl_arr[this_IN]['deviceID']
                            dvl_mode = dvl_arr[this_IN]['mode']
                            
                            if this_IN in p_arr:
                                if not 'p_out' in p_arr[this_IN]:
                                    continue
                                check_huawei = 1 if dvl_model == "sun2000-50ktl" or re.search(r'sun2000', dvl_model) else 0
                                if check_huawei == 1:
                                    p_out=round(float(p_arr[this_IN]['p_out']),1)
                                    p_max=round(float(p_arr[this_IN]['p_max']),1)
                                else:
                                    p_out=round(float(p_arr[this_IN]['p_out']),2)
                                    p_max=round(float(p_arr[this_IN]['p_max']),2)
                                
                                print(f'{this_IN}|{dvl_model}|p_out:{p_out}, p_max:{p_max}')
                                sum_IN += p_out
                                
                                if p_PM > 10:
                                    # print(f'p_PM:{p_PM}, p_arr:{p_arr[this_IN]}')
                                    # rgl_model = rgl_arr[dvl_model]
                                    # for reg, info in rgl_model.items():
                                    #     if info.get("name") == "p_max":
                                    #         print(f'{dvl_model}==={reg}==={info.get("multiply")}')
                                                    
                                    if p_out>=p_max or p_out==round(p_out,0):
                                        if check_huawei and p_max==p_max_arr[this_IN]:
                                            continue
                                        else:
                                            p_max_new = p_out+p_PM
                                            if p_max_new > p_max_arr[this_IN]:
                                                p_max_new=p_max_arr[this_IN]
                                            p_max_new=int(p_max_new)
                                            if 1:
                                                # print(f'== Write 485 [{this_IN}]: p_max_new = {p_max_new}')
                                                rgl_model = rgl_arr[dvl_model]
                                                instruments = self.main_m1_ini.tcpconfig(dvl_ip,int(dvl_id),int(dvl_port),1) 
                                                for reg, info in rgl_model.items():
                                                    if info.get("name") == "p_max":
                                                        rgl_multiply = float(info.get("multiply")) if "multiply" in info else 1
                                                        # print(f'=== Destination all:{reg} == { int(p_max_new/ rgl_multiply) }')
                                                        icc = 0
                                                        while icc < 3:
                                                            icc+=1
                                                            if self.main_m1_ini.writemodbustcp(instruments,int(reg),int(p_max_new/ rgl_multiply),1):
                                                                print("====[{}]Success==write:{}===".format(icc,int(p_max_new/ rgl_multiply)))
                                                                icc=3
                                                                time.sleep(1)
                                                instruments.close()
                                                if check_huawei == 1:
                                                    break
                                if p_PM < -10:
                                    if p_out > 1:
                                        p_max_new = p_out+p_PM
                                    if p_max_new < 1:
                                        p_max_new = 1
                                    p_max_new = int(p_max_new)
                                    if p_out > p_max_new:
                                        print(f'== Write 485 [{this_IN}]: p_max_new = {p_max_new}')
                                        rgl_model = rgl_arr[dvl_model]
                                        instruments = self.main_m1_ini.tcpconfig(dvl_ip,int(dvl_id),int(dvl_port),1) 
                                        for reg, info in rgl_model.items():
                                            if info.get("name") == "p_max":
                                                rgl_multiply = float(info.get("multiply")) if "multiply" in info else 1
                                                # print(f'=== Destination all:{reg} == { int(p_max_new/ rgl_multiply) }')
                                                icc = 0
                                                while icc < 3:
                                                    icc+=1
                                                    if self.main_m1_ini.writemodbustcp(instruments,int(reg),int(p_max_new/ rgl_multiply),1):
                                                        print("====[{}]Success==write:{}===".format(icc,int(p_max_new/ rgl_multiply)))
                                                        icc=3
                                                        time.sleep(1)
                                        instruments.close()
                                        break
                        print('==============================================')
                        print(f'Power Main  : {round(p_PM,2)} kW')
                        print(f'Sum inverter: {round(sum_IN,2)} kW')
                        print(f'Total Power : {round(p_PM+sum_IN,2)} kW')
            print('==================================================================')
            print(f'All workers finished is [{str(int(time.time())-self.start_time)}s]')
            # print(f'===M_ARR {m_arr}')
            
            print(f'===para_arr {self.para_arr}')
            print("==================================================================")
        except Exception as e:
            print(f'Except custom1 as {e}')
    
     