import ast
import json
import serial
import minimalmodbus
from pyModbusTCP.client import ModbusClient
import time
from datetime import datetime
import ftplib
import os
import numpy as np #convert Hex float
import subprocess
import requests
import RPi.GPIO as GPIO
import paho.mqtt.client as mqtt
requests.packages.urllib3.disable_warnings(requests.packages.urllib3.exceptions.InsecureRequestWarning)

class main_m1:
    def __init__(self, json_input={}):
        # Automatically set each key as an instance attribute
        for key, value in self._validate_json(json_input).items():
            # print(f"{key}: {value}")
            setattr(self, key, value)
        self.serial_port_rs485 = '/dev/ttyACM0'
        
    def show(self):
        for key, value in self.__dict__.items():
            print(f"{key}: {value}")
     
    def _validate_json(self, json_input):
        """Check if input is valid JSON and return as dict."""
        if json_input is None:
            return {}
        
        if isinstance(json_input, dict):
            # Already a Python dict, fine
            return json_input
        elif isinstance(json_input, str):
            try:
                return json.loads(json_input)
            except json.JSONDecodeError:
                raise ValueError("Invalid JSON string")
        else:
            raise TypeError("Input must be a JSON string or dict")

    def is_json(self,wsJson):
        try:
            json.loads(wsJson)
            return True
        except ValueError as e:
            return False
     
    def read_file(self,pathFile):
        try:
            res_txt = ""
            with open(pathFile, "r") as f:
                res_txt = f.read()
            return res_txt
        except Exception as e:
            return ""
 
    def write_file(self,filename,data,mode='w'):
        try:
            with open(filename, mode) as f:
                res_txt = data
                f.write(res_txt)
            return True   # success
        except Exception as e:
            print(f"Error writing file: {e}")
            return False  # failure
    
    def log_action(self,msg,typelog,lmode):
        # import glob
        try:
            log_dir = os.path.dirname(__file__)
            logdirNames = os.path.join(log_dir, "log_action/"+str(self.deviceSN))
            if self.ensure_dir_with_perms(logdirNames, mode=0o777 ,debug=0):
                pass
            # if not os.path.isdir(log_dir+"/log_action"):
            #     os.mkdir(log_dir+"/log_action")
            status_log_action = False
            time_l = time.time()
            mlog = str(int(time_l))+"|"+msg+"\n"
            # print(mlog)
            if not os.path.exists(logdirNames):
                os.makedirs(logdirNames)

            if typelog == "log5":
                time_test = datetime.fromtimestamp(int(int(time_l)/300) * 300)
                date_y = time_test.strftime("%Y%m%d%H%M")
                path_log = logdirNames+"/"+str(self.deviceSN)+"_log5_"+str(date_y)+".txt"

                # date_filter = time_test.strftime("%Y%m%d")
                # if int(datetime.now().hour) == 1 and int(datetime.now().minute) >= 0 and int(datetime.now().second) <= 10:
                #     file = os.listdir(logdirNames)
                #     for ifile in file:
                #         if "log5_" in ifile:
                #             if not date_filter in ifile:
                #                 if ".txt" in ifile:
                #                     fname = ifile[:ifile.find('.')]
                #                     if os.path.exists(logdirNames+'/'+fname+'.zip'):
                #                         os.remove(logdirNames+'/'+ifile)
                #                     else:
                #                         if zip_file(logdirNames+'/'+ifile):
                #                             os.remove(logdirNames+'/'+ifile)

                if not os.path.isfile(path_log):
                    # print("========== WRITE 555555")
                    self.write_file(str(path_log),str(mlog),"w")
                    # subprocess.call(['chmod', '0777', str(path_log)])
                    os.system('sudo chmod 777 {}'.format(str(path_log)))
                    status_log_action = True
                    
                else:
                    # print("========== WRITE 6666")
                    self.write_file(str(path_log),str(mlog),str(lmode))
                    # os.system('sudo chmod 777 {}'.format(str(path_log)))
                    # subprocess.call(['chmod', '0777', str(path_log)])
                    status_log_action = False

            elif typelog == "log1":
                time_test = datetime.fromtimestamp(int(int(time_l)/86400) * 86400)
                date_y = time_test.strftime("%Y%m%d")
                path_log = logdirNames+"/"+str(self.deviceSN)+"_log1_"+str(date_y)+".txt"
                # if not os.path.exists(logdirNames):
                if not os.path.isfile(path_log):
                    self.write_file(str(path_log),str(mlog),"w")
                    os.system('sudo chmod 777 {}'.format(str(path_log)))
                else:
                    self.write_file(str(path_log),str(mlog),str(lmode))
                    # os.system('sudo chmod 777 {}'.format(str(path_log)))
                status_log_action = True

            elif typelog == "logserver1":
                time_test = datetime.fromtimestamp(int(int(time_l)/86400) * 86400)
                date_y = time_test.strftime("%Y%m%d")
                path_log = logdirNames+"/"+str(self.deviceSN)+"_logserver1_"+str(date_y)+".txt"
                if not os.path.exists(logdirNames):
                    self.write_file(str(path_log),str(mlog),"w")
                    os.system('sudo chmod 777 {}'.format(str(path_log)))

                else:
                    self.write_file(str(path_log),str(mlog),str(lmode))
                    # os.system('sudo chmod 777 {}'.format(str(path_log)))
                status_log_action = True

            return status_log_action
        except Exception as e:
            mlog_err = "act_log_action|{}".format(e)
            self.log_error(mlog_err,"event","a")
            return False
    
    def log_error(self,msg,typelog,lmode=""):
        try:
            log_dir = os.getcwd()
            logdirNames = os.path.join(log_dir, "log_err/"+str(self.deviceSN))
            if not os.path.isdir(log_dir+"/log_err"):
                os.mkdir(log_dir+"/log_err")
            status_log_action = False
            time_l = time.time()
            date_l = datetime.fromtimestamp(time_l).strftime("%Y-%m-%d %H:%M:%S")
            mlog = str(date_l)+"|"+msg+"\n"
            if not os.path.exists(logdirNames):
                os.makedirs(logdirNames)
            if typelog == "event":
                time_test = datetime.fromtimestamp(time_l)
                date_y = time_test.strftime("%Y%m%d")
                path_log = logdirNames+"/"+self.deviceSN+"_event_"+str(date_y)+".txt"

                if not os.path.isfile(path_log):
                    self.write_file(str(path_log),str(mlog),"w")
                    os.system('sudo chmod 777 {}'.format(str(path_log)))
                    status_log_action = True
                else:
                    self.write_file(str(path_log),str(mlog),str(lmode))
                    status_log_action = False
            return status_log_action
        except Exception as e:
            return False
        
    def log_device(self,msg,typelog,lmode="w"):
        try:
            log_dir = os.getcwd()
            logdirNames = os.path.join(log_dir, "log_device/"+str(self.deviceSN))
            if not os.path.isdir(log_dir+"/log_device"):
                os.mkdir(log_dir+"/log_device")
            status_log_action = False
            time_l = time.time()
            # mlog = str(date_l)+"|"+msg+"\n"
            mlog = msg+"\n"
            # print(mlog)
            if not os.path.exists(logdirNames):
                os.makedirs(logdirNames)
            if typelog == "device":
                time_test = datetime.fromtimestamp(time_l)
                date_y = time_test.strftime("%Y%m%d")
                path_log = logdirNames+"/"+self.deviceSN+"_"+typelog+"_"+str(date_y)+".txt"

                if not os.path.isfile(path_log):
                    self.write_file(str(path_log),str(mlog),"w")
                    os.system('sudo chmod 777 -R {}'.format(log_dir+"/log_device"))
                    status_log_action = True
                else:
                    self.write_file(str(path_log),str(mlog),str(lmode))
                    status_log_action = False
            return status_log_action
        except Exception as e:
            mlog_err = "act_log_device|{}".format(e)
            self.log_error(mlog_err,"event","a")
            return False
    
    def log_server(self,msg,typelog,lmode="w"):
        try:
            # log_dir = os.path.dirname(__file__)
            log_dir = os.getcwd()
            logdirNames = os.path.join(log_dir, "dlog/"+str(self.deviceSN))
            # if ensure_dir_with_perms(log_dir+"/dlog", mode=0o777 ,debug=0):
            #     pass
            # if not os.path.isdir(log_dir+"/dlog"):
            #     os.mkdir(log_dir+"/dlog")
            status_log_action = False
            time_l = int(time.time()/300)*300+300
            date_l = datetime.fromtimestamp(time_l).strftime("%Y-%m-%d %H:%M:%S")
            mlog = str(int(time.time()))+"|"+msg+"\n"
            if self.ensure_dir_with_perms(logdirNames, mode=0o777 ,debug=0):
                pass
            # if not os.path.exists(logdirNames):
            #     os.makedirs(logdirNames)
            if typelog:
                # time_test = datetime.fromtimestamp(int(int(time_l)/86400) * 86400)
                time_test = datetime.fromtimestamp(time_l)
                date_y = time_test.strftime("%Y%m%d%H%M")
                path_log = logdirNames+"/"+self.deviceSN+"_"+typelog+"_"+str(date_y)+".txt"

                if not os.path.isfile(path_log):
                    self.write_file(str(path_log),str(mlog),"w")
                    os.system('sudo chmod 777 {}'.format(str(path_log)))
                    status_log_action = True
                else:
                    self.write_file(str(path_log),str(mlog),str(lmode))
                    status_log_action = False
            return status_log_action
        except Exception as e:
            mlog_err = "act|{}".format(e)
            self.log_error(mlog_err,"event","a")
            return False
    
    def ensure_dir_with_perms(self,path, mode=0o777 ,debug=0):
        import stat
        try:
            # 1. Check if directory exists, create if not
            if not os.path.exists(path):
                os.makedirs(path, exist_ok=True)
                if debug:
                    print(f"[{self.get_current()}][directory] >> Created directory: {path}")
            else:
                if debug:
                    print(f"[{self.get_current()}][directory] >> Directory exists: {path}")

            # 2. Get current permissions
            current_mode = stat.S_IMODE(os.stat(path).st_mode)
                
            if debug:
                print(f"[{self.get_current()}][permission] >> Current permissions: {oct(current_mode)}")

            # 3. Set permissions if different
            if current_mode != mode:
                os.chmod(path, mode)
                if debug:
                    print(f"[{self.get_current()}][permission] >> Permissions updated to: {oct(mode)}")
            else:
                if debug:
                    print(f"[{self.get_current()}][permission] >> Permissions already correct.")
            return True
        except Exception as e:
                    
            if debug:
                print(f'[{self.get_current()}][error] >> {e}')
            return False
    
    def get_current(self):
        time_l = time.time()
        time_test = datetime.fromtimestamp(int(time_l))
        date_time = time_test.strftime("%Y-%m-%d %H:%M:%S")
        return date_time
    
    def rtuconfig(self,ID=1,BR=9600,PT=serial.PARITY_NONE,timeouts=1):
        instrumentrtu = minimalmodbus.Instrument(self.serial_port_rs485, ID)  # port name, slave address (in decimal)
        instrumentrtu.serial.port                  # this is the serial port name
        instrumentrtu.serial.baudrate = BR       # Baud
        instrumentrtu.serial.bytesize = 8
        instrumentrtu.serial.stopbits = 1
        instrumentrtu.serial.parity   = PT
        instrumentrtu.serial.timeout  = timeouts         # seconds
        # this is the slave address number
        instrumentrtu.mode = minimalmodbus.MODE_RTU   # rtu or ascii mode
        instrumentrtu.clear_buffers_before_each_transaction = True
        return instrumentrtu
    
    def readmodbusrtu(self,instrumentrtu,x,y,refn): #Addtess,Length,function 3/4
        try:
            # reg = instrumentrtu.read_register(registeraddress: int, number_of_decimals: int = 0, functioncode: int = 3, signed: bool = False) 
            # https://minimalmodbus.readthedocs.io/en/stable/internalminimalmodbus.html#minimalmodbus.Instrument.read_registers 
            reg = instrumentrtu.read_registers(x, y, int(refn))
            instrumentrtu.serial.close()
            if (len(reg)) == y:
                # print("====================================================",reg)
                return {"data":repr(reg),"error":"","result":1}
            else:
                return {"error":"readmodbus RTU fail","result":0}
                # print("readmodbus RTU fail")
        except Exception as error:
            # print("[!] Exception occurred: ", error)
            mlog_err = "act|{}".format(error)
            self.log_error(mlog_err,"event","a")
            return {"error":"{}".format(error),"result":0}
        
    def tcpconfig(self,Host,ID=1,Port=502,timeouts=1):
        # global instrument
        instrument = ModbusClient(host=Host, port=Port, unit_id=ID, auto_open=True,auto_close=True, timeout=timeouts) #timeout=2
        # instrument = ModbusClient(host=Host, port=502, unit_id=ID, auto_open=True, auto_close=True, timeout=1000)
        return instrument
        
    def readmodbustcp(self,instrument,x,y,refn): #Addtess,Length,function 3/4
        try:
            if refn == 3:
                reg = instrument.read_holding_registers(x, y)
            elif refn == 4:
                reg = instrument.read_input_registers(x, y)
            elif refn == 1:
                reg = instrument.read_coils(x, y)
            # ii = 0
            # time_start_r = int(time.time())
            # while ii < 3 and int(int(time.time()) -time_start_r) < 2:
            #     ii += 1
            #     # print("===act_readmodbustcp=={}".format(reg))
                
            #     if reg!=None:
            #         ii=3
            #         print("===readmodbustcp Break!!==///// {}".format(len(reg)))
            #         break
            #     if reg is None:
            #         # print("===act_readmodbustcp=={}".format(reg))

            #         if refn == 3:
            #             reg = instrument.read_holding_registers(x, y)
            #         elif refn == 4:
            #             reg = instrument.read_input_registers(x, y)
            #         elif refn == 1:
            #             reg = instrument.read_coils(x, y)
            #     time.sleep(0.1)

            # # print("===act_readmodbustcp=={}".format(reg))
            if (len(reg)) == y:
                instrument.close()
                return {"data":repr(reg),"error":"","result":1}
            else:
                instrument.close()
                return {"error":"readmodbus TCP fail","result":0}
                # print("readmodbus1 fail")
        except Exception as error:
            # print("[!] Exception readmodbus TCP : ", error)
            instrument.close()
            mlog_err = "act_readmodbustcp|{}".format(error)
            # print("==[{},{}]=={}".format(x,y,mlog_err))
            return {"error":"{}".format(error),"result":0}
    
    def writemodbustcp(self,instrument,register,value,timeouts=0.1):
        try:
            # if instrument.write_single_coil(register,bool(value)):
            #     time.sleep(timeouts)
            #     return True
            if instrument.write_single_register(register,value):
                time.sleep(timeouts)
                # instrument.close()
                return True
            else:
                # instrument.close()
                return False

        except Exception as e:
            # instrument.close()
            print("[!] Write modbus TCP Exception error {}".format(e))
            mlog_err = "act|{}".format(e)
            self.log_error(mlog_err,"event","a")
            return False
        
    def ftp_download(self,src,dst):
        try:
            ftp = ftplib.FTP()
            # host = "172.16.0.65"
            # port = 2002
            host = str(self.ftp_host)
            port = int(self.ftp_port)
            # print("Host===",host, port)

            timeouts = 3
            src_fname = os.path.basename(src)
            src_path = os.path.dirname(src)
            dst_fname = os.path.basename(dst)
            # print(src_path,src_fname,dst_fname)

            ftp.connect(host, port, timeouts)
            # print(ftp.getwelcome())
            # ftp.login("meowftp", "Asefa@2o23")
            # print(str(ftp_u), str(ftp_p))
            ftp.login(str(self.ftp_u), str(self.ftp_p))

            # ftp.cwd('/dconfig/'+serial_main+'/')
            ftp.cwd(src_path)
            # ftp.sendcmd('SITE CHMOD 777 '+file_name)
            # print(ftp.dir())
            # with open('test_001.py', 'wb') as f:
            # path_filename_dl = os.path.dirname(__file__)+dst

            script_dir = os.path.dirname(os.path.abspath(__file__))
            path_filename_dl = os.path.join(script_dir, dst.lstrip('/'))

            # print(path_filename_dl)

            'RETR '+src_fname
            if ftp.retrbinary(f'RETR {src_fname}', open(path_filename_dl, 'wb').write):
                ftp.quit()
                os.system('sudo chmod 777 '+path_filename_dl)
                    
                return True
            else:
                return False
        except Exception as e:
            mlog_err = "act_ftp_download|{}".format(e)
            self.log_error(mlog_err,"event","a")
            print("error {}".format(e))
            return False

    def ftp_upload(self,src,dst):
        try:
            ftp = ftplib.FTP()
            # host = "172.16.0.65"
            # port = 2002
            host = str(self.ftp_host)
            port = int(self.ftp_port)
            # print("Host====",host, port)
            timeouts = 3
            src_fname = os.path.basename(src)
            src_path = os.path.dirname(src)
            dst_fname = os.path.basename(dst)
            dst_path = os.path.dirname(dst)
            # print(src_path,src_fname)
            # print(dst_path+'==',str(dst_fname))
            # print("SRC ===="+str(src))
            ftp.connect(host, port, timeouts)
            # ftp.login("meowftp", "Asefa@2o23")
            ftp.login(str(self.ftp_u), str(self.ftp_p))

            ftp.cwd(dst_path)
            current_path = ftp.pwd()
            # print("Current remote path:", current_path)
            # print("Connected successfully:", ftp.getwelcome())
            # print(f'src:{src}')
            # print(f'dst:{dst}')
            if os.path.exists(src.lstrip('/')):
                file = open(src.lstrip('/'),'rb')
                if ftp.storbinary(f'STOR {dst_fname}', file):
                    ftp.sendcmd('SITE CHMOD 777 '+str(dst_fname))
                    ftp.quit()
                    return True
                else:
                    ftp.quit()
                    return False
            else:
                ftp.quit()
                return False
        except Exception as e:
            mlog_err = "act_ftp_upload|{}".format(e)
            self.log_error(mlog_err,"event","a")
            print("error {}".format(e))
            return False

    def hex_to_signed(self,s):
        if not isinstance(s, str):
            raise ValueError("string required")
        if 0 == len(s):
            raise ValueError("string empty")
        sign_bit_mask = 1 << (len(s)*4-1)
        other_bits_mask = sign_bit_mask - 1
        val = int(s, 16)
        return -(val & sign_bit_mask) | (val & other_bits_mask)

    def convertfloat32(self,x,y):
        data_bytes = np.array([  int(hex(y),16) ,  int(hex(x),16) ], dtype=np.uint16)
        data_as_float = data_bytes.view(dtype=np.float32)
        return data_as_float

    def convertint_signed(self,bx):
        Int = bx - 0x10000 if bx & 0x8000 else bx
        return Int

    def convertint_unsigned(self,bx):
        Int = int(str(bx))
        return Int

    def convertlong16_signed(self,ax):
        long16 = ""
        long16 = self.hex_to_signed(str(hex(ax))[2:6].rjust(4, '0'))
        # print(str(hex(ax))[2:6].rjust(4, '0'))
        return long16
    
    def convertlong32(self,cx,cy):
        long32 = ""
        long32 = int((str(hex(cx))[2:6].rjust(4, '0')  +  str(hex(cy))[2:6].rjust(4, '0')),16)
        # long32 = int((str(hex(cx))[2:6]  +  str(hex(cy))[2:6]),16)
        return long32

    def convertlong32_signed(self,ax,ay):
        long32 = ""
        long32 = self.hex_to_signed(str(hex(ax))[2:6].rjust(4, '0')  +  str(hex(ay))[2:6].rjust(4, '0'))
        # long323 = np.array([  int((str(hex(cx))[2:6]  +  str(hex(cy))[2:6]),16) ], dtype=np.int32)/1000
        # print(str(hex(ax))[2:6].rjust(4, '0'), str(hex(ay))[2:6].rjust(4, '0'))
        return long32

    def convertlong64(self,ax,ax2,ay,ay2):
        long64 = ""
        long64 = int((str(hex(ax))[2:6].rjust(4, '0') + str(hex(ax2))[2:6].rjust(4, '0') + str(hex(ay))[2:6].rjust(4, '0') + str(hex(ay2))[2:6].rjust(4, '0')),16)
        return long64

    def convertlong64_signed(self,ax,ax2,ay,ay2):
        long64 = ""
        long64 = self.hex_to_signed( str(hex(ax))[2:6].rjust(4, '0')  + str(hex(ax2))[2:6].rjust(4, '0')  +  str(hex(ay))[2:6].rjust(4, '0') + str(hex(ay2))[2:6].rjust(4, '0') )
        # print(str(hex(ax))[2:6].rjust(4, '0'), str(hex(ax2))[2:6].rjust(4, '0'), str(hex(ay))[2:6].rjust(4, '0'), str(hex(ay2))[2:6].rjust(4, '0'))
        return long64

    def convertfloat(self,dx,dy):
        # data_bytes = np.array([  int(hex(reg[dy]),16) ,  int(hex(reg[dx]),16) ], dtype=np.uint16)
        data_bytes = np.array([  int(hex(dx),16) ,  int(hex(dy),16) ], dtype=np.uint16)
        data_as_float = data_bytes.view(dtype=np.float32)
        return data_as_float

    def convertToInt(self,mantissa_str):
        power_count = -1
        mantissa_int = 0
        for i in mantissa_str:
            mantissa_int += (int(i) * pow(2, power_count))
            power_count -= 1
            
        return (mantissa_int + 1)

    def hex2dec(self,strHex):
        try:
            ieee_32 = str(bin(int(str(strHex),16)).ljust(8, '0'))
            # if print_debug:
            #     # print(ieee_32)
            #     print(ieee_32[0],"|",ieee_32[2 : 10],"|",(int(ieee_32[2 : 10],2)-127))
            sign_bit = int(ieee_32[0])
            exponent_bias = int(ieee_32[2 : 10],2)
            exponent_unbias = exponent_bias - 127
            mantissa_str = ieee_32[10 : ]
            mantissa_int = self.convertToInt(mantissa_str)
            real_no = pow(-1, sign_bit) * mantissa_int * pow(2, exponent_unbias)
        except IOError:
            print("Failed to read from rtu")
            real_no=0
        return real_no

    def convert_data(self,data_read,reg_by_model,start_reg):
        data_command_cv = {}
        try:
            i_regis = 0
            # print("======...",len(data_read))
            # print(data_read,start_reg)
            for i_para in range(len(data_read)):
                if str(start_reg) in reg_by_model:
                    units = reg_by_model[str(start_reg)]['unit'] if "unit" in reg_by_model[str(start_reg)] else ""
                    decimal = int(reg_by_model[str(start_reg)]['decimal'])
                    multiply = float(reg_by_model[str(start_reg)]['multiply'])

                    if reg_by_model[str(start_reg)]['type'].lower() == "float32":
                        val_cv = float(self.convertfloat32(data_read[i_para],data_read[i_para+1])[0])
                        # data_command_cv[reg_by_model[str(start_reg)]['name']] = {"val":str(round(val_cv*multiply,decimal)),"unit":units}
                        data_command_cv[reg_by_model[str(start_reg)]['name']] = str(round(val_cv*multiply,decimal))
                        i_para += 1
                    elif reg_by_model[str(start_reg)]['type'].lower() == "float32 inverse":
                        val_cv = float(self.convertfloat32(data_read[i_para+1],data_read[i_para])[0])
                        data_command_cv[reg_by_model[str(start_reg)]['name']] = str(round(val_cv*multiply,decimal))
                        i_para += 1
                    elif reg_by_model[str(start_reg)]['type'].lower() == "int sign16":
                        val_cv = int(self.convertint_signed(data_read[i_para]))
                        data_command_cv[reg_by_model[str(start_reg)]['name']] = str(round(val_cv*multiply,decimal))
                        i_para += 1
                    elif reg_by_model[str(start_reg)]['type'].lower() == "int unsign16":
                        val_cv = int(self.convertint_unsigned(data_read[i_para]))
                        data_command_cv[reg_by_model[str(start_reg)]['name']] = str(round(val_cv*multiply,decimal))
                        i_para += 1
                    elif reg_by_model[str(start_reg)]['type'].lower() == "int16 binary":
                        val_cv = data_read[i_para]
                        data_command_cv[reg_by_model[str(start_reg)]['name']] = str(val_cv)
                        i_para += 1
                    elif reg_by_model[str(start_reg)]['type'].lower() == "long unsign32":
                        val_cv = float(self.convertlong32(data_read[i_para],data_read[i_para+1]))
                        data_command_cv[reg_by_model[str(start_reg)]['name']] = str(round(val_cv*multiply,decimal))
                        i_para += 1
                    elif reg_by_model[str(start_reg)]['type'].lower() == "long unsign32 inverse":
                        val_cv = float(self.convertlong32(data_read[i_para+1],data_read[i_para]))
                        data_command_cv[reg_by_model[str(start_reg)]['name']] = str(round(val_cv*multiply,decimal))
                        i_para += 1
                    elif reg_by_model[str(start_reg)]['type'].lower() == "long sign32":
                        val_cv = float(self.convertlong32_signed(data_read[i_para],data_read[i_para+1]))
                        data_command_cv[reg_by_model[str(start_reg)]['name']] = str(round(val_cv*multiply,decimal))
                        i_para += 1
                    elif reg_by_model[str(start_reg)]['type'].lower() == "long unsign64":
                        val_cv = float(self.convertlong64(data_read[i_para],data_read[i_para+1],data_read[i_para+2],data_read[i_para+3]))
                        data_command_cv[reg_by_model[str(start_reg)]['name']] = str(round(val_cv*multiply,decimal))
                        i_para += 3
                    elif reg_by_model[str(start_reg)]['type'].lower() == "long sign64":
                        val_cv = float(self.convertlong64_signed(data_read[i_para],data_read[i_para+1],data_read[i_para+2],data_read[i_para+3]))
                        data_command_cv[reg_by_model[str(start_reg)]['name']] = str(round(val_cv*multiply,decimal))
                        i_para += 3

                    # print(data_command_cv)
                    # # print(reg_by_model[str(start_reg)])
                    # if reg_by_model[str(start_reg)]['name'] == "sm" or reg_by_model[str(start_reg)]['name'] == "md":
                    #     # print("====data_command_cv==",data_command_cv[reg_by_model[str(start_reg)]['name']])
                    #     k_val = float(data_command_cv[reg_by_model[str(start_reg)]['name']]['val'])
                    #     print("===Status Alarm ",i_para,start_reg,reg_by_model[str(start_reg)]['name'],int(k_val))
                    #     if int(k_val) == 0:
                start_reg+=1
                i_regis += 1

            return data_command_cv
        except Exception as e:
            mlog_err = "convert_data|{}".format(e)
            # log_error(mlog_err,"event","a")
            return data_command_cv

    def get_ipv4_from_nic(self, interface):
        import psutil
        import socket
        interface_addrs = psutil.net_if_addrs().get(interface) or []
        for snicaddr in interface_addrs:
            if snicaddr.family == socket.AF_INET:
                return snicaddr.address
            
    def check_internet(self):
        try:
            a = subprocess.Popen("ping -c 1 -W 0.1 -s 0 8.8.8.8", stdout=subprocess.PIPE, shell=True)
            a.wait(timeout=1)
            if a.poll() == 0:
                return True
            else:
                return False
        except OSError as error:
            return False
        except Exception as e:
            print("[!] Exception is {}".format(e))
            # mlog_err = "act_check_internet|{}".format(e)
            # self.log_error(mlog_err,"event","a")
            return False
    
    def zip_file(self,pathFile):
        from zipfile import ZipFile
        import zipfile
        try:
            # print(pathFile)
            # print("ZipFile....."+str(pathFile))
            if os.path.exists(pathFile):
                f_dir = os.path.dirname(pathFile)
                f_name = os.path.basename(pathFile)
                f_name = f_name[:f_name.find('.')]
                with ZipFile(f_dir+'/'+f_name+'.zip', 'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as zip:
                    zip.write(f_dir+'/'+f_name+'.txt', f_name+'.txt')
                    os.system('sudo chmod 777 {}'.format(str(f_dir+'/'+f_name+'.zip')))
                    st = os.stat(f_dir+'/'+f_name+'.zip')
                    # print(st.st_size)
                    if os.path.exists(f_dir+'/'+f_name+'.zip') and st.st_size > 76:
                        # last_var = f_name[len(f_name)-2:]

                        # if last_var == "00" or last_var == "15" or last_var == "30" or last_var == "45" :
                        #     interest_val = {"meter_SN":"D00010d","measure_val":"e_p"}
                        #     retr = read_e_p(f_dir,f_name+'.txt',interest_val,positions="first")
                        #     if retr != "":
                        #         self.write_file(f_dir+"/log15_e_p.txt",retr,"w")
                        os.remove(f_dir+'/'+f_name+'.txt')
                        return True
                    else:
                        return False
            else:
                return False
        except Exception as e:
            print("Error {}".format(e))
            mlog_err = "act_zip_file|{}".format(e)
            self.log_error(mlog_err,"event","a")
            return False
        
    def clear_log(self,path,data,last_clear_log):
        # global last_clear_log

        try:
            time_l = time.time()
            time_test = datetime.fromtimestamp(time_l)
            date_y = time_test.strftime("%Y%m%d")

            time_check = int(int(time.time()) / 86400) * 86400 - (3 * 86400) # -1 day
            time_check_01 = datetime.fromtimestamp(time_check)
            date_check_01= time_check_01.strftime("%Y%m%d")
            # print(date_check_01)

            time_interval = data['time_interval'] if 'time_interval' in data else 1
            time_offset = data['time_offset'] if 'time_offset' in data else 0
            if last_clear_log == 0:
                last_clear_log = int(int(time.time()/time_interval)*time_interval) + time_interval + time_offset
            elif int(time.time()) > last_clear_log:
                if os.path.exists(path):
                    for filename in os.listdir(path):
                        opt = ""
                        if "_device_" in filename:
                            opt = filename.split(self.deviceSN+"_device_")[1].split(".")[0]
                        elif "_event_" in filename:
                            opt = filename.split(self.deviceSN+"_event_")[1].split(".")[0]
                        elif "_log5_" in filename:
                            opt = filename.split(self.deviceSN+"_log5_")[1].split(".")[0]
                            opt = opt[:len(opt)-4]
                        elif "_log1_" in filename:
                            opt = filename.split(self.deviceSN+"_log1_")[1].split(".")[0]
                            opt = opt[:len(opt)]
                        # print("===OPT==",opt)
                        # fname_save = filename[:filename.find('.')]
                        

                        if int(opt) < int(date_y):
                            fname_save = filename[:filename.find('.')]

                            pathFile = os.path.dirname(path)+"/"+self.deviceSN+"/"+filename
                            pathFile2 = os.path.dirname(path)+"/"+self.deviceSN+"/"+fname_save
                            if ".zip" in filename and ".txt" in filename:
                                print("==Remove file:",pathFile2+".txt")
                                os.remove(pathFile2+".txt")
                                # os.remove("/home/pi/Desktop/python/log_device/M117289601136254/M117289601136254_device_20250120.txt")

                            if ".txt" in filename and not ".zip" in filename:
                                # print(os.path.dirname(path))
                                self.zip_file(pathFile)
                                # print("Zip file {}".format(opt),pathFile)
                            if int(opt) < int(date_check_01):
                                os.remove(pathFile)
                                # print("Delete file :",pathFile)
                        # else:
                        #     print("today {}".format(opt))
                    last_clear_log = int(int(time.time()/time_interval)*time_interval) + time_interval + time_offset
                    return True
                else:
                    return False

            else:
                return False
            
        except Exception as e:
            mlog_err = "act|{}".format(e)
            self.log_error(mlog_err,"event","a")
            return False    
        
    def clear_log_event(self,path,data,last_clear_log_event):
        # global last_clear_log_event

        try:
            time_l = time.time()
            time_l = int(int(time.time()) / 86400) * 86400 - (7 * 86400) # -7 day

            time_test = datetime.fromtimestamp(time_l)
            date_y = time_test.strftime("%Y%m%d")

            time_check = int(int(time.time()) / 86400) * 86400 - (7 * 86400) # -7 day
            time_check_01 = datetime.fromtimestamp(time_check)
            date_check_01= time_check_01.strftime("%Y%m%d")
            # print(date_check_01)

            time_interval = data['time_interval'] if 'time_interval' in data else 1
            time_offset = data['time_offset'] if 'time_offset' in data else 0
            if last_clear_log_event == 0:
                last_clear_log_event = int(int(time.time()/time_interval)*time_interval) + time_interval + time_offset
                return True,last_clear_log_event
            elif int(time.time()) > last_clear_log_event:
                if os.path.exists(path):

                    for filename in os.listdir(path):
                        opt = ""
                        if "_device_" in filename:
                            opt = filename.split(self.deviceSN+"_device_")[1].split(".")[0]
                        elif "_event_" in filename:
                            opt = filename.split(self.deviceSN+"_event_")[1].split(".")[0]
                        elif "_log5_" in filename:
                            opt = filename.split(self.deviceSN+"_log5_")[1].split(".")[0]
                            opt = opt[:len(opt)-4]
                        elif "_log1_" in filename:
                            opt = filename.split(self.deviceSN+"_log1_")[1].split(".")[0]
                            opt = opt[:len(opt)]
                        # print("===OPT=={}=={}".format(opt,filename))
                        # print("===Time=={}==={}".format(str(opt),str(date_y)))
                        # fname_save = filename[:filename.find('.')]
                        

                        if int(opt) < int(date_y):
                            fname_save = filename[:filename.find('.')]

                            pathFile = os.path.dirname(path)+"/"+self.deviceSN+"/"+filename
                            pathFile2 = os.path.dirname(path)+"/"+self.deviceSN+"/"+fname_save
                            if ".zip" in filename and ".txt" in filename:
                                # print("==Remove file:",pathFile2+".txt")
                                os.remove(pathFile2+".txt")
                                mlog_err = "clear_log_event()|remove|"+pathFile
                                self.log_error(mlog_err,"event","a")
                                # os.remove("/home/pi/Desktop/python/log_device/M117289601136254/M117289601136254_device_20250120.txt")
                            if int(opt) < int(date_check_01):
                                os.remove(pathFile)
                                mlog_err = "clear_log_event()|remove|"+pathFile
                                # mlog_err = cmd_id+"|"+dev_list+"|"+act+"|"+data_mb_read['error']
                                self.log_error(mlog_err,"event","a")
                            if ".txt" in filename and not ".zip" in filename:
                                # print(os.path.dirname(path))
                                self.zip_file(pathFile)
                                mlog_err = "clear_log_event()|zip|"+pathFile
                                self.log_error(mlog_err,"event","a")

                                # print("Zip file {}".format(opt),pathFile)
                            
                                # print("Delete file :",pathFile)
                        # else:
                        #     print("today {}".format(opt))
                    last_clear_log_event = int(int(time.time()/time_interval)*time_interval) + time_interval + time_offset
                    return True,last_clear_log_event
                else:
                    return False,last_clear_log_event

            else:
                return False,last_clear_log_event
            
        except Exception as e:
            mlog_err = "act|{}".format(e)
            # log_error(mlog_err,"event","a")
            return False,last_clear_log_event

    def clear_log_file(self,path,data,lasttime_clear_log):
        try:
            time_l = time.time()
            time_l = int(int(time.time()) / 86400) * 86400 - (3 * 86400) # -7 day
            time_l_day = int(int(time.time()) / 86400) * 86400 - (1 * 86400) # -7 day

            time_test = datetime.fromtimestamp(time_l)
            time_test_day = datetime.fromtimestamp(time_l_day)
            date_y = time_test.strftime("%Y%m%d")
            date_y_day = time_test_day.strftime("%Y%m%d")

            time_check = int(int(time.time()) / 86400) * 86400 - (2 * 86400) # -7 day
            time_check_01 = datetime.fromtimestamp(time_check)
            date_check_01= time_check_01.strftime("%Y%m%d")
            # print(date_check_01)
            # print(f'===lasttime_clear_log==now:{int(time.time())}=={lasttime_clear_log}')

            time_interval = data['time_interval'] if 'time_interval' in data else 1
            time_offset = data['time_offset'] if 'time_offset' in data else 0
            if lasttime_clear_log == 0:
                lasttime_clear_log = int(int(time.time()/time_interval)*time_interval) + time_interval + time_offset
                return True,lasttime_clear_log
            elif int(time.time()) > lasttime_clear_log:
                print(f'===Active ==== {lasttime_clear_log}===path:{path}')
                lasttime_clear_log = int(int(time.time()/time_interval)*time_interval) + time_interval + time_offset
                if os.path.exists(path):

                    for filename in os.listdir(path):
                        opt = ""
                        if "_device_" in filename:
                            opt = filename.split(self.deviceSN+"_device_")[1].split(".")[0]
                        elif "_event_" in filename:
                            opt = filename.split(self.deviceSN+"_event_")[1].split(".")[0]
                        elif "_log5_" in filename:
                            opt = filename.split(self.deviceSN+"_log5_")[1].split(".")[0]
                            opt = opt[:len(opt)-4]
                        elif "_log1_" in filename:
                            opt = filename.split(self.deviceSN+"_log1_")[1].split(".")[0]
                            opt = opt[:len(opt)]
                        # print("===OPT=={}=={}".format(opt,filename))
                        # print("===Time=={}==={}".format(str(opt),str(date_y)))
                        # fname_save = filename[:filename.find('.')]
                        

                        if int(opt) < int(date_y):
                            fname_save = filename[:filename.find('.')]

                            pathFile = os.path.dirname(path)+"/"+self.deviceSN+"/"+filename
                            pathFile2 = os.path.dirname(path)+"/"+self.deviceSN+"/"+fname_save
                            if ".zip" in filename and ".txt" in filename:
                                # print("==Remove file:",pathFile2+".txt")
                                os.remove(pathFile2+".txt")
                                mlog_err = "clear_log_file()|remove|"+pathFile
                                self.log_error(mlog_err,"event","a")
                                # os.remove("/home/pi/Desktop/python/log_device/M117289601136254/M117289601136254_device_20250120.txt")
                            if int(opt) < int(date_check_01):
                                os.remove(pathFile)
                                mlog_err = "clear_log_file()|remove|"+pathFile
                                # mlog_err = cmd_id+"|"+dev_list+"|"+act+"|"+data_mb_read['error']
                                self.log_error(mlog_err,"event","a")
                            if ".txt" in filename and not ".zip" in filename:
                                # print(os.path.dirname(path))
                                self.zip_file(pathFile)
                                mlog_err = "clear_log_file()|zip|"+pathFile
                                self.log_error(mlog_err,"event","a")

                                # print("Zip file {}".format(opt),pathFile)
                            
                                # print("Delete file :",pathFile)
                        # print(date_y_day)
                        if int(opt) < int(date_y_day):
                            fname_save = filename[:filename.find('.')]

                            pathFile = os.path.dirname(path)+"/"+self.deviceSN+"/"+filename
                            pathFile2 = os.path.dirname(path)+"/"+self.deviceSN+"/"+fname_save
                            
                            if ".txt" in filename and not ".zip" in filename:
                                print(pathFile)
                                
                                print(os.path.dirname(path))
                                self.zip_file(pathFile)
                                mlog_err = "clear_log_file()|zip|"+pathFile
                                self.log_error(mlog_err,"event","a")
                            
                        #     print("today {}".format(opt))
                    lasttime_clear_log = int(int(time.time()/time_interval)*time_interval) + time_interval + time_offset
                    return True,lasttime_clear_log
                else:
                    return False,lasttime_clear_log

            else:
                return False,lasttime_clear_log
            
        except Exception as e:
            mlog_err = "act|{}".format(e)
            # log_error(mlog_err,"event","a")
            return False,lasttime_clear_log

    def clear_log5_data(self,path,data,last_clear_log5_data):
        # global last_clear_log5_data
        # global err_arr

        try:
            time_l = time.time()
            time_l = int(int(time.time()) / 86400) * 86400 - (7 * 86400) # -7 day

            time_test = datetime.fromtimestamp(time_l)
            date_y = time_test.strftime("%Y%m%d")

            time_check = int(int(time.time()) / 86400) * 86400 - (7 * 86400) # -7 day
            time_check_01 = datetime.fromtimestamp(time_check)
            date_check_01= time_check_01.strftime("%Y%m%d")
            # print(date_check_01)

            time_interval = data['time_interval'] if 'time_interval' in data else 1
            time_offset = data['time_offset'] if 'time_offset' in data else 0
            if last_clear_log5_data == 0:
                last_clear_log5_data = int(int(time.time()/time_interval)*time_interval) + time_interval + time_offset
                return True,last_clear_log5_data
            elif int(time.time()) > last_clear_log5_data:
                # err_arr = dict()
                if os.path.exists(path):

                    for filename in os.listdir(path):
                        opt = ""
                        if "_device_" in filename:
                            opt = filename.split(self.deviceSN+"_device_")[1].split(".")[0]
                        elif "_event_" in filename:
                            opt = filename.split(self.deviceSN+"_event_")[1].split(".")[0]
                        elif "_log5_" in filename:
                            opt = filename.split(self.deviceSN+"_log5_")[1].split(".")[0]
                            opt = opt[:len(opt)-4]
                        elif "_log1_" in filename:
                            opt = filename.split(self.deviceSN+"_log1_")[1].split(".")[0]
                            opt = opt[:len(opt)]
                        # print("===OPT=={}=={}".format(opt,filename))
                        # print("===Time=={}==={}".format(str(opt),str(date_y)))
                        # fname_save = filename[:filename.find('.')]
                        

                        if int(opt) < int(date_y):
                            fname_save = filename[:filename.find('.')]

                            pathFile = os.path.dirname(path)+"/"+self.deviceSN+"/"+filename
                            pathFile2 = os.path.dirname(path)+"/"+self.deviceSN+"/"+fname_save
                            if ".zip" in filename and ".txt" in filename:
                                # print("==Remove file:",pathFile2+".txt")
                                os.remove(pathFile2+".txt")
                                mlog_err = "clear_log5_data()|remove|"+pathFile
                                self.log_error(mlog_err,"event","a")
                                # os.remove("/home/pi/Desktop/python/log_device/M117289601136254/M117289601136254_device_20250120.txt")
                            if int(opt) < int(date_check_01):
                                os.remove(pathFile)
                                mlog_err = "clear_log5_data()|remove|"+pathFile
                                # mlog_err = cmd_id+"|"+dev_list+"|"+act+"|"+data_mb_read['error']
                                self.log_error(mlog_err,"event","a")
                            if ".txt" in filename and not ".zip" in filename:
                                # print(os.path.dirname(path))
                                self.zip_file(pathFile)
                                mlog_err = "clear_log5_data()|zip|"+pathFile
                                self.log_error(mlog_err,"event","a")

                                # print("Zip file {}".format(opt),pathFile)
                            
                                # print("Delete file :",pathFile)
                        # else:
                        #     print("today {}".format(opt))
                    last_clear_log5_data = int(int(time.time()/time_interval)*time_interval) + time_interval + time_offset
                    return True,last_clear_log5_data
                else:
                    return False,last_clear_log5_data

            else:
                return False,last_clear_log5_data
            
        except Exception as e:
            mlog_err = "act|{}".format(e)
            # log_error(mlog_err,"event","a")
            return False,last_clear_log5_data
    
    def http_send(self, mode,  msg_input={}, cmd_id = "", timeout = 3,g_cne="cVpWUUl6ZGR1QUUxRy9XL1lWYWpiN1lPSUIzZE9YUmRHdTJtT1ZqK2c5bz0="):
        
        # global g_cne
        # time_hb = time.time()
        try:
            # print("==msg_input==",msg_input)
            deviceSN = self.deviceSN
            http_server = self.httpServer if self.httpServer else "http://api.mdbiot.com/vx_mdbiot_api.php"
            mqtt_server = self.mqttBroker if self.mqttBroker else "mqtt.mdbiot.com"
            mqtt_port = self.mqttBroker if self.mqttBroker else 1883
            m1_class = self
            
            a1 = {}
            a1["mode"] = mode
            a1["device_SN"] = deviceSN
            if cmd_id != "":
                a1["cmdid"] = cmd_id
                
            if mode == "check_ws":
                msg_input['httpServer'] = http_server
                msg_input['mqttBroker'] = mqtt_server
                msg_input['mqttPort'] = mqtt_port
            a1["data"] = msg_input
            a1["counter"] = str(int(time.time()) - self.time_counter)
            a1["ts"] = int(time.time())

            # print("http_send()==to=={}===".format(http_server), json.dumps(a1))
            # if mode == 'reply':
            #     mqttc3 = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2)
            #     mqttc3.connect(mqtt_server, mqtt_port, 60)
            #     mqttc3.publish("res/"+deviceSN, json.dumps(a1))

            # httpSend = requests.post(http_server,data={"mode":"WSDevice","WSData": json.dumps(a1),"cne":g_cne},headers={"User-Agent": "INNO/2025"},verify=False,timeout=timeout)
            httpSend = requests.post(http_server+"?device_sn="+deviceSN,data={"mode":"WSDevice","WSData": json.dumps(a1)},headers={"User-Agent": "INNO/2025","cne":g_cne},verify=False,timeout=timeout)
            httpSend.raise_for_status()
            # print(f"=== Status Http {httpSend.text}")
            # if httpSend.status_code == 200:
            print("[{}][{}][http] >> server | {}".format(m1_class.get_current(),deviceSN,json.dumps(a1)))
            if httpSend.status_code == 200:
                # print("===httpSend=="+str(httpSend.text))
                # print("[{}][http] >> server | {}".format(deviceSN,json.dumps(a1)))
                g_cne_arr = json.loads(httpSend.text) if m1_class.is_json(httpSend.text) else {}
                if isinstance(g_cne_arr, dict):                
                    g_cne = g_cne_arr['cne'] if 'cne' in g_cne_arr else ''
                    if mode.lower() == 'status':
                        ms_minus = int(g_cne_arr['ms_minus']) if 'ms_minus' in g_cne_arr else 0
                        if 'device_config' in g_cne_arr:
                            if g_cne_arr['device_config'] is not None:
                                # data_alarm = g_cne_arr['device_config'] if m1_class.is_json(g_cne_arr['device_config']) else {}
                                data_alarm = g_cne_arr['device_config']
                                # print("===data_alarm==",data_alarm)
                                m1_class.write_file('alarm_config.json',json.dumps(data_alarm),'w')
                                os.system('sudo chmod 777 alarm_config.json')
                        # print("===httpSend=="+str(httpSend.text))
                print("[{}][{}][http] << server | {}".format(m1_class.get_current(),deviceSN,httpSend.text))

                return True,g_cne_arr
            else:
                return False,{}
        except Exception as e:
            print(f"==Error as ={e}")
            mlog_err = "http_send()|{}|{}|{}".format(e,mode,msg_input)
            m1_class.log_error(mlog_err,"event","a")
            return False,{}

    def on_connect(self, client, userdata, flags, reason_code, properties):
        # print(f"Connected with result code {reason_code}")
        m1_class = self
        print("[{}][{}][mqtt] >> server | {}".format(m1_class.get_current(),self.deviceSN,f"Connected with result code {reason_code}"))

        # Subscribing in on_connect() means that if we lose the connection and
        # reconnect then subscriptions will be renewed.
        client.subscribe("meow/{}".format(self.deviceSN))
    def on_message(self, client, userdata, msg):
        # global ts_cmd
        # global g_cne
        m1_class = self
        deviceSN = self.deviceSN
        mqtt_server = self.mqttBroker
        mqtt_port = self.mqttPort
        
        try:
            msg_arr = dict()
            message = (msg.payload).decode("utf-8")
            time_conn = m1_class.get_current()
            print("[{}][{}][mqtt] << server | {}".format(m1_class.get_current(),deviceSN,message))

            # print(str(time_conn)+'|'+(message))
            # print(msg.topic+" "+str(msg.payload))
            msg = message
            if m1_class.is_json(msg):
                msg_arr = json.loads(msg)
                time_data = m1_class.get_current()
                
                # writefile(msg,'cma.json','w')
                ts_e = int(time.time())
                if msg_arr:
                    if 'ts_cmd' in msg_arr:
                        # print("=====",msg_arr['ts_cmd'])
                        ts_cmd = msg_arr['ts_cmd']
                        diff_cmd = int(int(time.time())-int(ts_cmd))

                        if diff_cmd > 120 and diff_cmd != int(time.time()):
                            ts_cmd = int(time.time())
                            os.system("pm2 restart all")

                    if 'mode' in msg_arr: #special function()
                        # print(msg_arr['mode'],"==",msg_arr['data'])
                        msg_mode = msg_arr['mode']
                        ts_cmd = int(time.time())

                        if msg_mode == "check_ws":
                            pass
                        elif msg_mode == "cmd":
                            msg_cmdid = msg_arr['cmd_id'] if "cmd_id" in msg_arr else "C" + str(int(time.time()*1000))
                            cmd_id = msg_cmdid
                            msg_data = msg_arr['data']
                            data_output = {}
                            # print("===Output_CMD:",msg_data)
                            if "getfile" in msg_data:
                                def download(url,target):
                                    get_response = requests.get(url,stream=True)
                                    file_name  = url.split("/")[-1]
                                    # print(os.getcwd())
                                    with open(os.getcwd()+"/config/"+target, 'wb') as f:
                                        for chunk in get_response.iter_content(chunk_size=1024):
                                            if chunk: # filter out keep-alive new chunks
                                                f.write(chunk)
                                        os.system('sudo chmod 777 '+os.getcwd()+"/config/"+target)

                                path_dl = list(msg_data['getfile'].keys())[0]
                                path_tg = list(list(msg_data['getfile'].values())[0].keys())[0]
                                print("==path :",path_dl)
                                print("==Target :",path_tg)
                                download(path_dl,path_tg)
                            elif "EV" in msg_data:
                                data_output = {}
                                if "config" in msg_data['EV']:
                                    if "write" in msg_data['EV']['config']:
                                        print("==path_EV",msg_data['EV']['config']['write'])
                                        cev_txt = m1_class.read_file('cev.json') if os.path.exists('cev.json') else ""
                                        cev_arr = json.loads(cev_txt) if m1_class.is_json(cev_txt) else {}
                                        data_output[cmd_id] = {"writeconfig":msg_data['EV']['config']}
                                        print("===Output:",data_output)
                                        # writefile(json.dumps(data_output),'cev.json','w')
                                        # writefile(json.dumps(data_output),'cma2.json','w')
                                        os.system('sudo chmod 777 cev.json')
                                    if "read" in msg_data['EV']['config']:
                                        print("==path_EV",msg_data['EV']['config']['read'])
                                        cev_txt = m1_class.read_file('cev.json') if os.path.exists('cev.json') else ""
                                        cev_arr = json.loads(cev_txt) if m1_class.is_json(cev_txt) else {}
                                        data_output[cmd_id] = {"readconfig":msg_data['EV']['config']}
                                        print("===Output:",data_output)
                                        # writefile(json.dumps(data_output),'cev.json','w')
                                        # writefile(json.dumps(data_output),'cma2.json','w')
                                        os.system('sudo chmod 777 cev.json')
                            elif "uploadfile" in msg_data:
                                msg_data_arr = msg_data['uploadfile']
                                print(msg_data_arr['src'],msg_data_arr['dst'])
                                if m1_class.ftp_upload(msg_data_arr['src'],msg_data_arr['dst']):
                                    mqttc3 = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2)
                                    mqttc3.connect(mqtt_server, mqtt_port, 60)
                                    mqttc3.publish("res/"+deviceSN, "upload success. " + json.dumps(msg_data_arr['src']))
                                    m1_class.http_send('reply', {'uploadfile':'success','data':msg_data_arr['src']}, cmd_id=cmd_id)
                                else:
                                    mqttc3 = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2)
                                    mqttc3.connect(mqtt_server, mqtt_port, 60)
                                    mqttc3.publish("res/"+deviceSN, "upload not found. " + json.dumps(msg_data_arr['src']))
                                    m1_class.http_send('reply', {'uploadfile':'505','data':msg_data_arr['src']}, cmd_id=cmd_id)
                            elif "downloadfile" in msg_data:
                                msg_data_arr = msg_data['downloadfile']
                                print(msg_data_arr['src'],msg_data_arr['dst'])
                                if m1_class.ftp_download(msg_data_arr['src'],msg_data_arr['dst']):
                                    mqttc3 = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2)
                                    mqttc3.connect(mqtt_server, mqtt_port, 60)
                                    mqttc3.publish("res/"+deviceSN, "download success. " + json.dumps(msg_data_arr['src']))
                                    m1_class.http_send('reply', {'download':'success','data':msg_data_arr['src']}, cmd_id=cmd_id)
                                else:
                                    mqttc3 = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2)
                                    mqttc3.connect(mqtt_server, mqtt_port, 60)
                                    mqttc3.publish("res/"+deviceSN, "download not found. " + json.dumps(msg_data_arr['src']))
                                    m1_class.http_send('reply', {'download':'505','data':msg_data_arr['src']}, cmd_id=cmd_id)
                            elif "VPN" in msg_data:
                                print("===VPN",msg_data['VPN'])
                                # global status_vpn
                                status_vpn = self.status_vpn
                                if int(msg_data['VPN']) == 0:
                                    self.status_vpn = 0
                                    # os.system("pm2 restart all")
                                    print("pm2 restart all")

                                if int(msg_data['VPN']) == 1:
                                    # status_vpn = 1 if status_vpn == 0 else 0
                                    print("connect VPN")
                                    if m1_class.get_ipv4_from_nic("tun0") != None:
                                        os.system("sudo killall openvpn")
                                    # /home/pi/Desktop/python/VPN/VPN
                                    subprocess.Popen("python3 /home/mdbcare/python/zrunvpn.py", shell=True)

                                    if status_vpn == 0:
                                        self.status_vpn = 1
                                    if status_vpn > 0:
                                        a1 = dict()
                                        a1["ipvpn"] = m1_class.get_ipv4_from_nic("tun0")
                                        mqttc3 = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2)
                                        mqttc3.connect("mqtt.mdbiot.com", 1883, 60)
                                        mqttc3.publish("meow/"+deviceSN, json.dumps(a1))
                                        # mqttc3.disconnect()
                                else:
                                    a1 = dict()
                                    # a1["mode"] = "reply"
                                    a1["ipvpn"] = m1_class.get_ipv4_from_nic("tun0")
                                    mqttc3 = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2)
                                    mqttc3.connect("mqtt.mdbiot.com", 1883, 60)
                                    mqttc3.publish("meow/"+deviceSN, json.dumps(a1))
                            else: 
                                msg_cmdid = msg_arr['cmd_id'] if "cmd_id" in msg_arr else "C" + str(int(time.time()*1000))
                                cmd_id = msg_cmdid
                                msg_data = msg_arr['data']
                                data_output = {}
                                # print("===Read==",m1_class.read_file('cma.json'))

                                if True:
                                    cma_txt = m1_class.read_file('cma.json')
                                    data_output = json.loads(cma_txt) if m1_class.is_json(cma_txt) else {}
                                    print("===========================================================")
                                    print("===ssssPre read===",data_output)
                                    print("============================")
                                    data_output[cmd_id] = {msg_mode:msg_data}
                                    # data_output = {cmd_id:{msg_mode:msg_data}}
                                    print("===ssssssOutput:",data_output)
                                    print("===========================================================")
                                    m1_class.write_file('cma.json',json.dumps(data_output),'w')
                                    # writefile(json.dumps(data_output),'cma2.json','w')
                                    os.system('sudo chmod 777 cma.json')
                                    # os.system('sudo chmod 777 cma2.json')
                                

                                        
                        else:
                            # if "cmd_id" in msg_arr:

                            msg_cmdid = msg_arr['cmd_id'] if "cmd_id" in msg_arr else "C" + str(int(time.time()*1000))
                            cmd_id = msg_cmdid
                            msg_data = msg_arr['data']
                            data_output = {}
                            # print("===Read==",m1_class.read_file('cma.json'))

                            cma_txt = m1_class.read_file('cma.json')
                            data_output = json.loads(cma_txt) if m1_class.is_json(cma_txt) else {}
                            # print("===Pre read===",data_output)


                            data_output[cmd_id] = {msg_mode:msg_data}
                            # data_output = {cmd_id:{msg_mode:msg_data}}
                            # print("===Output:",data_output)
                            m1_class.write_file('cma.json',json.dumps(data_output),'w')
                            # writefile(json.dumps(data_output),'cma2.json','w')
                            os.system('sudo chmod 777 cma.json')
                            # os.system('sudo chmod 777 cma2.json')
                        
                            
                        # if "restart" in msg_arr:
                        #     os.system('sudo reboot')
                        if msg_mode == "restart":
                            os.system('sudo reboot')
                        if msg_mode == "pm2restart":
                            os.system("sudo pm2 restart all")
                        if msg_mode == "pip":
                            msg_data = msg_arr['data']
                            # print(msg_data)
                            # os.system("lxterminal -e sudo pip install paho-mqtt")
                            # if "sudo" in msg_data:
                            #     os.system(msg_data)
                            os.system(msg_data)
                        if msg_mode == "uploadfile":
                            msg_data = msg_arr['data']
                            print("=======",msg_data['src'])
                            msg_txt = {}
                            if m1_class.ftp_upload(msg_data['src'],msg_data['dst']):
                                msg_txt['mode'] = msg_mode
                                msg_txt['result'] = 1
                                msg_txt['text'] = msg_data
                                # pass
                                # mqttc3 = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2)
                                # mqttc3.connect(mqtt_server, mqtt_port, 60)
                                # mqttc3.publish("res/"+deviceSN, "upload success")
                            else:
                                msg_txt['mode'] = msg_mode
                                msg_txt['result'] = 0
                                msg_txt['text'] = msg_data
                                print(f'fail ')
                                # mqttc3 = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2)
                                # mqttc3.connect(mqtt_server, mqtt_port, 60)
                                # mqttc3.publish("res/"+deviceSN, "upload not found")
                            print(f'===msg_txt: {msg_txt}')
                            # http_send('reply', msg_txt, cmd_id=cmd_id)
                            m1_class.http_send('reply', msg_input=msg_txt, cmd_id=cmd_id)
                            # http_send('reply', msg_data, cne_input=g_cne, cmd_id=cmd_id)
                        if msg_mode == "downloadfile":
                            msg_data = msg_arr['data']
                            if m1_class.ftp_download(msg_data['src'],msg_data['dst']):
                                mqttc3 = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2)
                                mqttc3.connect(mqtt_server, mqtt_port, 60)
                                mqttc3.publish("res/"+deviceSN, "download success")
                                msg_txt['mode'] = msg_mode
                                msg_txt['result'] = 1
                                msg_txt['text'] = msg_data['src']
                            else:
                                mqttc3 = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2)
                                mqttc3.connect(mqtt_server, mqtt_port, 60)
                                mqttc3.publish("res/"+deviceSN, "download not found")
                                msg_txt['mode'] = msg_mode
                                msg_txt['result'] = 0
                                msg_txt['text'] = msg_data['src']
                            # http_send('reply', msg_data, cne_input=g_cne, cmd_id=cmd_id)
                            m1_class.http_send('reply', msg_input=msg_txt, cmd_id=cmd_id)
                        if msg_mode == "setconfig":
                            msg_data = msg_arr['data']
                            
                            print(f'=== setconfig: ==={msg_data}')
                            # print(f'=== path config: ==={path_fileconfig}')
                            main_txt = m1_class.read_file(self.path_def)
                            main_txt_arr    = json.loads(main_txt) if m1_class.is_json(main_txt) else {}
                            print(f'====main_txt_arr: ===={main_txt_arr.keys()}')

            else:
                time_data = m1_class.get_current()
                print(str(time_data)+' | '+str(msg))
            
        except Exception as e:
            print("[!] Exception is {}".format(e))



    # def worker(self,lock,k,p,c,meterSN,rgl,lasttime_send_status,m_arr,g_cne,para_arr):
    #     debug_ = True
        
    #     data_device_cmd = dict()
    #     return_status = dict()
    #     raw_read_arr = dict()
    #     # print(f'data : {p}')
    #     print(f'===PRE t_i_m_e==={datetime.fromtimestamp(lasttime_send_status).strftime("%Y-%m-%d %H:%M:%S")}')       
        
    #     with lock:
    #         if isinstance(p,dict):
    #             # print(f"Working on {n} - {p}")
    #             # print(rgl)
    #             if 'mode' in p:
    #                 # d0_arr = dict()
                    
    #                 if p['mode'].lower() == 'tcp':
    #                     if 'ipaddress' in p:
    #                         port_485 = int(p['port']) if 'port' in p else 502
    #                         deviceID_485 = int(p['deviceID']) if 'deviceID' in p else 1
    #                         instrument = self.tcpconfig(p['ipaddress'],deviceID_485,port_485,1)
    #                         # start_t = int(time.time())
    #                         start_reg = 0
    #                         for cmd_id in c:
    #                             for cmd_act in c[cmd_id]:
    #                                 return_status[cmd_act] = False
                                    
    #                                 cml_arr = c[cmd_id][cmd_act]
    #                                 if meterSN in cml_arr:
    #                                     if cmd_act == "read_holding_tcp":
    #                                         min_reg = min(cml_arr[meterSN])
    #                                         max_reg = max(cml_arr[meterSN])
    #                                         if min_reg == max_reg:
    #                                             max_reg=max_reg+2
    #                                         length_485 = int(max_reg - min_reg) if int(max_reg - min_reg) < 125 else 125
                                            
                                    
    #                                         data_mb_read = self.readmodbustcp(instrument,int(min_reg),int(length_485),3)
    #                                         # print(f"Working on {n} [{meterSN}] - {min_reg},{max_reg} = {len(data_mb_read)}")
    #                                         data_read = {}
    #                                         if "data" in data_mb_read:
    #                                             data_read = json.loads(data_mb_read['data']) if self.is_json(data_mb_read['data']) else ast.literal_eval(data_mb_read['data'])
    #                                             raw_read_arr[cmd_id] = data_read

    #                                     msg_req2 = {}
    #                                     msg_req2[cmd_id] = {"fn": cmd_act, "sn": meterSN, "params": cml_arr[meterSN]}
    #                                     msg_req = {"method": "req", "data": msg_req2}
    #                                     self.log_action(json.dumps(msg_req),"log5","a")
    #                                     self.log_action(json.dumps(msg_req),"log1","a")
    #                                     # print(msg_req)
    #                                     start_reg = min(cml_arr[meterSN]) if min(cml_arr[meterSN]) else 0
    #                                     data_command = {}
    #                                     if cmd_id in raw_read_arr:
    #                                         # print((rgl[p['model']]))
    #                                         data_command = self.convert_data(raw_read_arr[cmd_id],rgl[p['model']],start_reg)
                                            
    #                                         if debug_ == True:
    #                                             print("[{}][{}][modbusTCP] >> {} | {}".format(self.get_current(),self.deviceSN,meterSN,cml_arr[meterSN]))
    #                                             print("[{}][{}][modbusTCP] << {} | {}".format(self.get_current(),self.deviceSN,meterSN,data_command))
                                            
    #                                     if data_command != {}:
    #                                         # data_command_2[meterSN] = data_command
    #                                         # data_device_cmd[cmd_id] = data_command_2[meterSN]
    #                                         if not cmd_id in data_device_cmd:
    #                                             data_device_cmd[cmd_id] = {}
    #                                         data_device_cmd[cmd_id] = data_command
                                            
    #                                         data_res = dict()
    #                                         data_res_2 = dict()
    #                                         data_res_4 = dict()

    #                                         data_res_2['cmdid'] = cmd_id
    #                                         data_res_2['meter_SN'] = meterSN
    #                                         data_res_2['data']  = data_device_cmd[cmd_id]
                                            
    #                                         # data_res_4[dev_list] = convert_data(data_read,rgl_arr[deviceModel],start_reg)
    #                                         data_res_4[meterSN] =  data_command
    #                                         if cmd_id not in m_arr:
    #                                             m_arr[cmd_id] = {}
    #                                         m_arr[cmd_id] = data_res_4 #Global data meter

    #                                         if data_device_cmd[cmd_id]:
    #                                             data_res_2['result'] = 1
    #                                             data_res_2['error'] = ""
    #                                         else:
    #                                             data_res_2['result'] = 0
    #                                             data_res_2['error'] = ""


    #                                         data_res['method'] = "res"
    #                                         data_res['data'] = data_res_2
    #                                         msg_2_log = json.dumps(data_res)
    #                                         # if hostname == "172.16.21.114":
    #                                         # print(msg_2_log)
    #                                         status_res_log5 = self.log_action(msg_2_log,"log5","a")
    #                                         status_res_log1 = self.log_action(msg_2_log,"log1","a")
    #                                         return_status[cmd_act] = True
    #                 elif p['mode'].lower() == 'rtu':
    #                     if 'deviceID' in p:
    #                         # print(f"RTU on {p}")
    #                         dvl_id = int(p['deviceID']) if 'deviceID' in p else 1
    #                         dvl_baurdrate = int(p['baurdrate']) if 'baurdrate' in p else 9600
    #                         dvl_parity = p['parity'] if 'parity' in p else 'none'
    #                         parity_list = {'none':serial.PARITY_NONE,'even':serial.PARITY_EVEN}
    #                         instrument = self.rtuconfig(dvl_id,dvl_baurdrate,parity_list[dvl_parity],timeouts=1)
    #                         # start_t = int(time.time())
    #                         start_reg = 0
    #                         for cmd_id in c:
    #                             for cmd_act in c[cmd_id]:
    #                                 return_status[cmd_act] = False
                                    
    #                                 cml_arr = c[cmd_id][cmd_act]
    #                                 if meterSN in cml_arr:
    #                                     if cmd_act == "read_holding_rtu":
    #                                         min_reg = min(cml_arr[meterSN])
    #                                         max_reg = max(cml_arr[meterSN])
    #                                         if min_reg == max_reg:
    #                                             max_reg=max_reg+2
    #                                         length_485 = int(max_reg - min_reg) if int(max_reg - min_reg) < 125 else 125
                                            
                                    
    #                                         data_mb_read = self.readmodbusrtu(instrument,int(min_reg),int(length_485),3)
    #                                         # print(f"Working on [{meterSN}] - {min_reg},{max_reg} = {len(data_mb_read)}")
    #                                         data_read = {}
    #                                         if "data" in data_mb_read:
    #                                             data_read = json.loads(data_mb_read['data']) if self.is_json(data_mb_read['data']) else ast.literal_eval(data_mb_read['data'])
    #                                             raw_read_arr[cmd_id] = data_read
    #                                     msg_req2 = {}
    #                                     msg_req2[cmd_id] = {"fn": cmd_act, "sn": meterSN, "params": cml_arr[meterSN]}
    #                                     msg_req = {"method": "req", "data": msg_req2}
    #                                     self.log_action(json.dumps(msg_req),"log5","a")
    #                                     self.log_action(json.dumps(msg_req),"log1","a")
    #                                     # print(msg_req)
    #                                     start_reg = min(cml_arr[meterSN]) if min(cml_arr[meterSN]) else 0
    #                                     data_command = {}
    #                                     if cmd_id in raw_read_arr:
    #                                         # print((rgl[p['model']]))
    #                                         data_command = self.convert_data(raw_read_arr[cmd_id],rgl[p['model']],start_reg)
                                            
    #                                         # if debug_ == True:
    #                                         print("[{}][{}][modbusRTU] >> {} | {}".format(self.get_current(),self.deviceSN,meterSN,cml_arr[meterSN]))
    #                                         print("[{}][{}][modbusRTU] << {} | {}".format(self.get_current(),self.deviceSN,meterSN,data_command))
                                            
    #                                     if data_command != {}:
    #                                         # data_command_2[meterSN] = data_command
    #                                         # data_device_cmd[cmd_id] = data_command_2[meterSN]
    #                                         if not cmd_id in data_device_cmd:
    #                                             data_device_cmd[cmd_id] = {}
    #                                         data_device_cmd[cmd_id] = data_command
                                            
    #                                         data_res = dict()
    #                                         data_res_2 = dict()
    #                                         data_res_4 = dict()

    #                                         data_res_2['cmdid'] = cmd_id
    #                                         data_res_2['meter_SN'] = meterSN
    #                                         data_res_2['data']  = data_device_cmd[cmd_id]
                                            
    #                                         # data_res_4[dev_list] = convert_data(data_read,rgl_arr[deviceModel],start_reg)
    #                                         data_res_4[meterSN] =  data_command
    #                                         if cmd_id not in m_arr:
    #                                             m_arr[cmd_id] = {}
    #                                         m_arr[cmd_id] = data_res_4 #Global data meter

    #                                         if data_device_cmd[cmd_id]:
    #                                             data_res_2['result'] = 1
    #                                             data_res_2['error'] = ""
    #                                         else:
    #                                             data_res_2['result'] = 0
    #                                             data_res_2['error'] = ""


    #                                         data_res['method'] = "res"
    #                                         data_res['data'] = data_res_2
    #                                         msg_2_log = json.dumps(data_res)
    #                                         # if hostname == "172.16.21.114":
    #                                         # print(msg_2_log)
    #                                         status_res_log5 = self.log_action(msg_2_log,"log5","a")
    #                                         status_res_log1 = self.log_action(msg_2_log,"log1","a")
    #                                         return_status[cmd_act] = True
                            
    #                         # tcpconfig(p['ipaddress'],int(p['deviceID']),int(p['port']),3)
    #                         # start_t = int(time.time())
    #                         start_reg = 0
    #                 elif p['mode'].lower() == 'recv':
    #                     # print(f"RECV on {n} - {p}")
    #                     start_reg = 0
    #                     for cmd_id in c:
    #                         for cmd_act in c[cmd_id]:
    #                             cml_arr = c[cmd_id][cmd_act]
    #                             if meterSN in cml_arr:
    #                                 # print(f'=={cmd_id}=={cml_arr[meterSN]}')
    #                                 if cmd_act == "recv_holding_rtu":
    #                                     min_reg = min(cml_arr[meterSN])
    #                                     max_reg = max(cml_arr[meterSN])
    #                                     length_485 = int(max_reg - min_reg)+4 if int(max_reg - min_reg)+4 < 125 else 125
    #                                     path_local = "/var/www/html/meow/textfile"
    #                                     local_data_arr = {}
    #                                     d0_arr_local = {}
    #                                     # print(f'Model : {rgl[p["model"]]}')
                                        
    #                                     # print(f"Working on {n} [{meterSN}] - {min_reg},{max_reg} = {len(path_local)}")
    #                                     if self.ensure_dir_with_perms(path_local, 0o777 ,debug=0):
    #                                         for filename in os.listdir(path_local):
    #                                             if filename.endswith('.txt'):
    #                                                 local_data = self.read_file(path_local + "/" + filename)
    #                                                 local_data_arr = json.loads(local_data) if self.is_json(local_data) else local_data
    #                                                 # print("==path Local==",local_data_arr)
    #                                                 if "mode" in local_data_arr:
    #                                                     if local_data_arr['mode'] == "status":
    #                                                         # print("==path Local==",local_data_arr['device_SN'],local_data_arr)
    #                                                         if local_data_arr['data'] != None:
    #                                                             # print(local_data_arr['data'])
    #                                                             if meterSN in local_data_arr['data']:
    #                                                                 d0_arr_local[meterSN] = local_data_arr['data'][meterSN]
    #                                                                 # if cmd_id not in m_arr:
    #                                                                 #     m_arr[cmd_id] = {}
    #                                                                 # if not meterSN in m_arr[cmd_id]:
    #                                                                 #     m_arr[cmd_id][meterSN] = {}
    #                                                                 # m_arr[cmd_id][meterSN] = local_data_arr['data'][meterSN]
    #                                                                 m_arr[cmd_id] = d0_arr_local
    #                                                                 print("[{}][{}][RECV] >> {} | {}".format(self.get_current(),self.deviceSN,meterSN,cml_arr[meterSN]))
    #                                                                 print("[{}][{}][RECV] << {} | {}".format(self.get_current(),self.deviceSN,meterSN,d0_arr_local[meterSN]))
                                                                    
    #                                                                 data_res = dict()
    #                                                                 data_res['method'] = "rec" #rec = receive data
    #                                                                 data_res['data'] = d0_arr_local
    #                                                                 msg_2_log = json.dumps(data_res)
    #                                                                 print("====================== LOG ==================================")
    #                                                                 print(msg_2_log)
    #                                                                 status_res_log5 = self.log_action(msg_2_log,"log5","a")
    #                                                                 print("========================================================")
    #                                                                 if meterSN in m_arr[cmd_id]:
    #                                                                     local_data_arr["data"].pop(meterSN)
    #                                                                 print(f'Local data: {local_data_arr["data"]}')
    #                                                                 self.write_file(path_local + "/" + filename,json.dumps(local_data_arr),"w")
                                                                    
    #                                                                 # for local_deviceSN in local_data_arr['data']:

    #                                                                 # if meterSN in d0_arr:
    #                                                                 #     d0_arr[meterSN].update(local_data_arr['data'][meterSN])
    #                                                                 # else:
    #                                                                 #     d0_arr[meterSN] = local_data_arr['data'][meterSN]
                        
    #                                 # data_res = dict()
    #                                 # data_res_2 = dict()
                                    
    #                                 # data_res['method'] = "rec" #rec = receive data
    #                                 # data_res['data'] = d0_arr
    #                                 # msg_2_log = json.dumps(data_res)
    #                                 # print(msg_2_log)
    #                                 # # status_res_log5 = log_action(msg_2_log,"log5","a")
    #                 elif p['mode'].lower() == 'cmd':
    #                     print("=============================================")
    #                     print(f'====={c}')
    #                     print("=============================================")
                    
                    
    #                 if not lasttime_send_status.value:
    #                     lasttime_send_status.value = 0
    #                 # print("DIFF====={}".format(int(time.time()) - int(lasttime_send_status.value)))
    #                 # print("===========Next {} ==================".format(datetime.fromtimestamp(lasttime_send_status.value).strftime("%Y-%m-%d %H:%M:%S")))
    #                 # print(f'=Type111=={type(dict(m_arr))} == {m_arr}')
                    
    #                 # //////////////////////////////////////////////////////////////
    #                 # print("===================================================")
    #                 # WSData_arr = {}
    #                 # for outer in m_arr.values():
    #                 #     for key, val in outer.items():
    #                 #         WSData_arr.setdefault(key, {}).update(val)
                    
    #                 # print(f'=====WSData_arr: {WSData_arr}')
    #                 # print("===================================================")
    #                 # //////////////////////////////////////////////////////////////
                    
    #                 if int(time.time()) >= int(lasttime_send_status.value):
    #                 # if int(time.time()) >= int(lasttime_send_status.value) or True:
    #                     t_i_m_e = int(self.cml_send)
    #                     # t_i_m_e = int(10)
    #                     # lasttime_send_status = int(int(time.time())/t_i_m_e)*t_i_m_e+t_i_m_e
    #                     # print(f'===t_i_m_e==={lasttime_send_status.value}')
    #                     # print(f'===t_i_m_e==={t_i_m_e}')
    #                     lasttime_send_status.value = int(time.time()) +t_i_m_e
    #                     # print(f'===t_i_m_e==={lasttime_send_status.value}')       
    #                     # print(f'===t_i_m_e==={datetime.fromtimestamp(lasttime_send_status.value).strftime("%Y-%m-%d %H:%M:%S")}')   
    #                     a1 = dict()
    #                     d0_arr = dict()
    #                     status_SI1 = GPIO.input(17)
    #                     status_SI2 = GPIO.input(27)
                        
    #                     status_SO1 = GPIO.input(23) #DO0
    #                     status_SO2 = GPIO.input(24) #DO1
    #                     status_SO1 = 1 if status_SO1 == 0 else 2
    #                     status_SO2 = 1 if status_SO2 == 0 else 2
    #                     d0_arr['SI'] = {'SI1':str(status_SI1),'SI2':str(status_SI2),'RL1':str(status_SO1),'RL2':str(status_SO2)}
    #                     if "para" in para_arr:
    #                         # d0_arr['para'] = para_arr["para"]
    #                         v_para = {}
    #                         v_para = para_arr["para"]
    #                         d0_arr['para'] = dict(v_para)
    #                         print(f'===para_arr: {d0_arr}')
    #                     # d0_arr = d0_arr | para_arr
    #                     # print(f'=Type=={type(dict(m_arr))} == {m_arr}')
                        
    #                     if isinstance(dict(m_arr),dict):
    #                         # print(f'==={m_arr}')
    #                         for m_cmdid in dict(m_arr):
    #                             for sn_meter in dict(m_arr)[m_cmdid]:
    #                                 # print("====sn_meter==={}".format(sn_meter))
    #                                 if sn_meter in dict(m_arr)[m_cmdid]:
    #                                     # print("===>> {} === {} == LEN:{}".format(m_cmdid,sn_meter,len(m_arr[m_cmdid][sn_meter])))
    #                                     if sn_meter in d0_arr:
    #                                         if isinstance(dict(m_arr)[m_cmdid][sn_meter], dict):
    #                                             d0_arr[sn_meter].update(dict(m_arr)[m_cmdid][sn_meter])
    #                                         else:
    #                                             print("Warning: Cannot update with non-dict:{}".format(type(dict(m_arr)[m_cmdid][sn_meter])))
    #                                             print("==Data is: {}".format(dict(m_arr)[m_cmdid][sn_meter]))
    #                                     else:
    #                                         d0_arr[sn_meter] = dict(m_arr)[m_cmdid][sn_meter]
                                        
    #                     a1["mode"] = "status"
    #                     a1["device_SN"] = self.deviceSN
    #                     a1["data"] = d0_arr
    #                     # if err_arr:
    #                     #     a1["error"] = err_arr
    #                     a1["counter"] = str(int(time.time()) - self.time_counter)
    #                     a1["ts"] = int(time.time())
    #                     a1["dt"] = datetime.fromtimestamp(int(time.time())).strftime("%Y-%m-%d %H:%M:%S")

    #                     # clear data
    #                     # m_arr = dict()  
    #                     # m_arr.clear()  
                        
                        
    #                     if self.log_server(json.dumps(a1),"log5","a"):
    #                         # time_counter = int(time.time())
    #                         m_arr.clear() 
    #                     # print(f"=== {a1}")
    #                     res_http = self.http_send('status',  d0_arr, cmd_id="",timeout=3,g_cne=g_cne.value)
    #                     if res_http[0]:
    #                         print(f'=== Send Http success {res_http}')
    #                         if not res_http[1] is None:
    #                             sec_count = res_http[1]['sec_count'] if 'sec_count' in res_http[1] else 60
    #                             lasttime_send_status.value = lasttime_send_status.value - sec_count
    #                             time_l = lasttime_send_status.value
    #                             time_test_cutoff_s = datetime.fromtimestamp(int(time_l))
    #                             time_test_cutoff_s = time_test_cutoff_s.strftime("%H:%M:%S")
    #                             print(f'Last time == {time_test_cutoff_s}')
    #                             print("==================================================")
    #                             if 'ms_minus' in res_http[1] and False:
    #                                 time_l = lasttime_send_status.value
    #                                 time_test_cutoff_s = datetime.fromtimestamp(int(time_l))
    #                                 time_test_cutoff_s = time_test_cutoff_s.strftime("%H:%M:%S")
    #                                 print(f'Pre time == {time_test_cutoff_s}')
    #                                 ms_minus = res_http[1]['ms_minus']
    #                                 lasttime_send_status.value = lasttime_send_status.value - ms_minus
    #                                 time_l = lasttime_send_status.value
    #                                 time_test_cutoff_s = datetime.fromtimestamp(int(time_l))
    #                                 time_test_cutoff_s = time_test_cutoff_s.strftime("%H:%M:%S")
    #                                 print(f'Last time == {time_test_cutoff_s}')
    #                                 print("==================================================")
    #                             if 'cne' in res_http[1]:
    #                                 g_cne.value = res_http[1]['cne'].encode('utf-8')
                                    
    #                     else:
    #                         print(f"=== Send Http Error ")
    #                 # print(m_arr)            
    #             # else:
    #             #     print(f"Working on {n} - {p}")
                    
    
