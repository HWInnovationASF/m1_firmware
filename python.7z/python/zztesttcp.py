import json
import time
from datetime import datetime
from pyModbusTCP.client import ModbusClient
from pyModbusTCP import utils

def tcpconfig(Host,ID,Port):
    global instrument
    instrument = ModbusClient(host=Host, port=Port, unit_id=ID, auto_open=True, timeout=1) #timeout=2
    # instrument = ModbusClient(host=Host, port=502, unit_id=ID, auto_open=True, auto_close=True, timeout=1000)

def readmodbustcp(x,y,refn): #Addtess,Length,function 3/4
    global reg
    try:
        # if refn == 1:
        #     reg = instrument.read_holding_registers(x, y)
        # elif refn == 3:
        #     reg = instrument.read_holding_registers(x, y)
        # elif refn == 4:
        #     reg = instrument.read_input_registers(x, y)

        if instrument.read_holding_registers(x, y):
            reg = instrument.read_holding_registers(x, y)
        elif instrument.read_input_registers(x, y):
            reg = instrument.read_input_registers(x, y)
        elif instrument.read_coils(x, y):
            reg = instrument.read_coils(x, y)

        if (len(reg)) == y:
        # if reg != None:
            # instrument.close()
            # return repr(reg)
            return {"data":repr(reg),"error":""}
        else:
            # instrument.close()

            return {"error":"readmodbus RTU fail"}
            # print("readmodbus1 fail")
    except Exception as error:
        print("[!] Exception occurred: ", error)
        # instrument.close()
        return {"error":"{}".format(error)}
    

def writemodbustcp(x,y,refn):
    try:
        # if instrument.write_single_coil(x, y):
        #     print("success")
        #     # time.sleep(0.1)
        #     return True
        # else:
        #     print("Fail")
        #     return False
        instrument.write_single_coil(x, y)


    except Exception as error:
        print("[!] Exception occurred: ", error)
        instrument.close()
        return {"error":"{}".format(error)}
    
def writemodbustcp_multi(x,y):
    try:
        if instrument.write_multiple_coils(x, y):
            print("success")
            # time.sleep(0.1)
        else:
            print("Fail")

    except Exception as error:
        print("[!] Exception occurred: ", error)
        instrument.close()
        return {"error":"{}".format(error)}
    
# inv_ip = [203,204,205,206,207,208]
inv_ip = [159]
while True:
    for i in inv_ip:
        print('172.16.21.{}'.format(str(i)))
        tcpconfig('172.16.21.{}'.format(str(i)),int(12),int(502))
        # tcpconfig('172.16.110.203',int(1),int(502))
        data_mb_read = {}
        data_mb_read['1'] = readmodbustcp(int(32095), int(2),3)['data'] #1
        # data_mb_read['1'] = readmodbustcp(int(41257), int(1),3)['data'] #1
        # data_mb_read['2'] = readmodbustcp(int(41265), int(1),3)['data'] #2
        # data_mb_read['3'] = readmodbustcp(int(41273), int(1),3)['data'] #3
        # data_mb_read['4'] = readmodbustcp(int(41281), int(1),3)['data'] #4
        # data_mb_read['5'] = readmodbustcp(int(41289), int(1),3)['data'] #5
        # data_mb_read['6'] = readmodbustcp(int(41297), int(1),3)['data'] #6
        # data_mb_read['7'] = readmodbustcp(int(41305), int(1),3)['data'] #7
        # data_mb_read['8'] = readmodbustcp(int(41313), int(1),3)['data'] #8
        # data_mb_read['9'] = readmodbustcp(int(41321), int(1),3)['data'] #9
        # data_mb_read['10'] = readmodbustcp(int(41329), int(1),3)['data'] #10
        # data_mb_read['11'] = readmodbustcp(int(41337), int(1),3)['data'] #11
        # data_mb_read['12'] = readmodbustcp(int(41345), int(1),3)['data'] #12
        # data_mb_read['13'] = readmodbustcp(int(41353), int(1),3)['data'] #13
        # data_mb_read['14'] = readmodbustcp(int(41361), int(1),3)['data'] #14
        # data_mb_read['15'] = readmodbustcp(int(41369), int(1),3)['data'] #15
        # data_mb_read['16'] = readmodbustcp(int(41377), int(1),3)['data'] #16
        # data_mb_read['17'] = readmodbustcp(int(41385), int(1),3)['data'] #17
        # data_mb_read['18'] = readmodbustcp(int(41393), int(1),3)['data'] #18
        # data_mb_read['19'] = readmodbustcp(int(41401), int(1),3)['data'] #19
        # data_mb_read['20'] = readmodbustcp(int(41409), int(1),3)['data'] #20
        # data_mb_read['21'] = readmodbustcp(int(41417), int(1),3)['data'] #21
        # data_mb_read['22'] = readmodbustcp(int(41425), int(1),3)['data'] #22
        # data_mb_read['23'] = readmodbustcp(int(41433), int(1),3)['data'] #23
        # data_mb_read['24'] = readmodbustcp(int(41441), int(1),3)['data'] #24
        print("==== {} =====".format(i),data_mb_read)
        instrument.close()
        # time.sleep(1)


# while True:
#     tcpconfig('172.16.110.204',int(1),int(502))
#     data_mb_read = readmodbustcp(int(41257), int(2),1)
# #     data_mb_read = readmodbustcp(int(41257), int(5),1)
#     #print("==== 111 =====",data_mb_read)
# #     time.sleep(1)
#     # writemodbustcp(int(40152),10000,6)

#     # if writemodbustcp(40152,10000,6):
#     #     print("Success")
#     # else:
#     #     print("===unSuccess")

#     # writemodbustcp(2,0,1)
#     # writemodbustcp(3,0,1)

#     # data_mb_read = readmodbustcp(int(1), int(3),1)
#     # print("==== 222 =====",data_mb_read)
#     time.sleep(2)

    # writemodbustcp(1,1,1)
    # writemodbustcp(2,1,1)
    # writemodbustcp(3,1,1)

    # data_mb_read = readmodbustcp(int(1), int(3),1)
    # print("==== 222 =====",data_mb_read)

# time_s = time.time()
# # aa=0
# while time.time() - time_s <= 3: aa = 1 

# print(aa)
