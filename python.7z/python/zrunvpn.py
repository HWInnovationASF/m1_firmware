import os
import subprocess

# os.system('sudo openvpn --config /home/pi/Desktop/python/VPN/VPN.ovpn')
os.system('sudo openvpn --config /home/mdbcare/python/VPN/VPN.ovpn')

# os.system('sudo openvpn --config /home/pi/Desktop/VPN.ovpn')
# os.system('ifconfig')
# subprocess.call('python bb.py', creationflags=subprocess.CREATE_NEW_CONSOLE)